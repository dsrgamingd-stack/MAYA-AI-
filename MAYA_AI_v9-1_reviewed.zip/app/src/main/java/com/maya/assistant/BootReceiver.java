package com.maya.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

/**
 * Android 10+ restricts launching activities from the background, and Android 14+
 * does not allow starting a microphone foreground service from BOOT_COMPLETED.
 * Therefore boot only posts a notification; the user taps it to open MAYA and
 * explicitly start microphone listening.
 */
public class BootReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "maya_boot";
    private static final int NOTIFICATION_ID = 78;

    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;

        SharedPreferences prefs = context.getSharedPreferences("maya_preferences", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("s_boot", false)) return;

        try {
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "MAYA startup", NotificationManager.IMPORTANCE_DEFAULT);
                channel.setDescription("फोन चालू होने पर MAYA खोलने की सूचना");
                manager.createNotificationChannel(channel);
            }

            Intent open = new Intent(context, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            open.putExtra("boot", true);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent pending = PendingIntent.getActivity(context, 78, open, flags);

            Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new Notification.Builder(context, CHANNEL_ID)
                    : new Notification.Builder(context);
            Notification notification = builder
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("MAYA तैयार है")
                    .setContentText("MAYA खोलने और सुनना शुरू करने के लिए टैप करें।")
                    .setContentIntent(pending)
                    .setAutoCancel(true)
                    .build();
            manager.notify(NOTIFICATION_ID, notification);
        } catch (SecurityException ignored) {
            // Notification permission may be denied. The user can still open MAYA manually.
        } catch (Exception ignored) {
            // A boot receiver must never crash the device startup flow.
        }
    }
}
