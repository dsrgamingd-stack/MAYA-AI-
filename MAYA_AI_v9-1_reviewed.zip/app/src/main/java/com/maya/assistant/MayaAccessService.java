package com.maya.assistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Bundle;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayDeque;
import java.util.List;

public class MayaAccessService extends AccessibilityService {
    private static MayaAccessService inst;
    @Override protected void onServiceConnected(){ inst=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}
    @Override public boolean onUnbind(Intent i){ inst=null; return super.onUnbind(i); }
    static boolean ready(){ return inst!=null; }

    private static boolean danger(String text,String word){
        String t=text.toLowerCase(), w=word.toLowerCase();
        String[] bad={"uninstall","अनइंस्टॉल","delete","हटाएं","हटाएँ","remove","factory reset"};
        for(String b:bad) if(t.contains(b)&&!w.contains(b)) return true;
        return false;
    }
    static boolean clickText(boolean exact,String... words){
        if(inst==null) return false;
        AccessibilityNodeInfo root=inst.getRootInActiveWindow();
        if(root==null) return false;
        for(String w:words){
            List<AccessibilityNodeInfo> l=root.findAccessibilityNodeInfosByText(w);
            if(l==null) continue;
            for(AccessibilityNodeInfo n:l){
                CharSequence tx=n.getText(), cd=n.getContentDescription();
                String t1=tx!=null?tx.toString().trim():"", t2=cd!=null?cd.toString().trim():"";
                if(exact&&!(t1.equalsIgnoreCase(w)||t2.equalsIgnoreCase(w))) continue;
                if(danger(t1+" "+t2,w)) continue;
                AccessibilityNodeInfo c=n;
                while(c!=null&&!c.isClickable()) c=c.getParent();
                if(c!=null&&c.isEnabled()&&c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            }
        }
        return false;
    }
    static boolean global(int action){ return inst!=null&&inst.performGlobalAction(action); }
    static boolean scroll(boolean forward){
        if(inst==null) return false;
        AccessibilityNodeInfo root=inst.getRootInActiveWindow();
        if(root==null) return false;
        ArrayDeque<AccessibilityNodeInfo> queue=new ArrayDeque<>();
        queue.add(root);
        while(!queue.isEmpty()){
            AccessibilityNodeInfo n=queue.poll();
            if(n.isScrollable()) return n.performAction(forward?AccessibilityNodeInfo.ACTION_SCROLL_FORWARD:AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
            for(int i=0;i<n.getChildCount();i++){ AccessibilityNodeInfo ch=n.getChild(i); if(ch!=null) queue.add(ch); }
        }
        return false;
    }
    static String screenText(){
        if(inst==null) return "";
        AccessibilityNodeInfo root=inst.getRootInActiveWindow();
        if(root==null) return "";
        StringBuilder sb=new StringBuilder();
        ArrayDeque<AccessibilityNodeInfo> queue=new ArrayDeque<>();
        queue.add(root);
        while(!queue.isEmpty()&&sb.length()<500){
            AccessibilityNodeInfo n=queue.poll();
            CharSequence t=n.getText(); if(t==null||t.length()==0) t=n.getContentDescription();
            if(t!=null&&t.length()>0&&t.length()<200) sb.append(t).append("। ");
            for(int i=0;i<n.getChildCount();i++){ AccessibilityNodeInfo ch=n.getChild(i); if(ch!=null) queue.add(ch); }
        }
        return sb.toString();
    }
    static boolean type(String text){
        if(inst==null) return false;
        AccessibilityNodeInfo root=inst.getRootInActiveWindow();
        if(root==null) return false;
        AccessibilityNodeInfo f=root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if(f==null) return false;
        Bundle b=new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text);
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b);
    }
    static boolean swipe(boolean up){
        if(inst==null) return false;
        android.util.DisplayMetrics dm=inst.getResources().getDisplayMetrics();
        float x=dm.widthPixels/2f, y1=dm.heightPixels*(up?.78f:.25f), y2=dm.heightPixels*(up?.25f:.78f);
        Path path=new Path(); path.moveTo(x,y1); path.lineTo(x,y2);
        GestureDescription.Builder b=new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(path,0,260));
        return inst.dispatchGesture(b.build(),null,null);
    }
}
