package com.maya.assistant;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

/** Takes a photo inside the app (no tap needed): shows a live preview, then captures on command. */
class CameraShot {
    interface Cb { void ready(); void done(Uri uri,String path); void fail(String why); }

    private final Activity act;
    private final boolean front;
    private final Cb cb;
    private FrameLayout overlay;
    private TextureView tv;
    private CameraDevice cam;
    private CameraCaptureSession session;
    private ImageReader reader;
    private HandlerThread th;
    private Handler bg;
    private Size prevSize, jpegSize;
    private int sensor=90;
    private String camId;
    private volatile boolean closed=false, captured=false;

    CameraShot(Activity a,boolean front,Cb cb){ this.act=a; this.front=front; this.cb=cb; }

    private Size pickPreview(Size[] sizes,Size jpeg){
        Size best=null;
        float want=(float)jpeg.getWidth()/jpeg.getHeight();
        for(Size s:sizes){
            if(s.getWidth()>1280||s.getHeight()>960) continue;
            float r=(float)s.getWidth()/s.getHeight();
            if(Math.abs(r-want)>0.03f) continue;
            if(best==null||s.getWidth()*s.getHeight()>best.getWidth()*best.getHeight()) best=s;
        }
        if(best==null) for(Size s:sizes) if(s.getWidth()<=1280&&s.getHeight()<=960&&(best==null||s.getWidth()*s.getHeight()>best.getWidth()*best.getHeight())) best=s;
        return best!=null?best:sizes[sizes.length-1];
    }
    private Size pickJpeg(Size[] sizes){
        Size best=null;
        for(Size s:sizes){
            long area=(long)s.getWidth()*s.getHeight();
            if(area>8000000L) continue;
            if(best==null||area>(long)best.getWidth()*best.getHeight()) best=s;
        }
        return best!=null?best:sizes[sizes.length-1];
    }

    void start(){
        try{
            final CameraManager cm=(CameraManager)act.getSystemService(Context.CAMERA_SERVICE);
            camId=null;
            for(String id:cm.getCameraIdList()){
                Integer lf=cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if(lf!=null&&lf==(front?CameraCharacteristics.LENS_FACING_FRONT:CameraCharacteristics.LENS_FACING_BACK)){ camId=id; break; }
            }
            if(camId==null){ fail("कैमरा नहीं मिला"); return; }
            CameraCharacteristics cc=cm.getCameraCharacteristics(camId);
            Integer so=cc.get(CameraCharacteristics.SENSOR_ORIENTATION); if(so!=null) sensor=so;
            StreamConfigurationMap map=cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if(map==null){ fail("कैमरा सेटिंग नहीं मिली"); return; }
            jpegSize=pickJpeg(map.getOutputSizes(ImageFormat.JPEG));
            prevSize=pickPreview(map.getOutputSizes(SurfaceTexture.class),jpegSize);
            th=new HandlerThread("maya-cam"); th.start(); bg=new Handler(th.getLooper());
            act.runOnUiThread(() -> {
                overlay=new FrameLayout(act);
                overlay.setBackgroundColor(0xff000000);
                tv=new TextureView(act);
                int sw=act.getResources().getDisplayMetrics().widthPixels, sh=act.getResources().getDisplayMetrics().heightPixels;
                int w=sw, h=(int)(sw*(float)prevSize.getWidth()/prevSize.getHeight());
                if(h>sh){ h=sh; w=(int)(sh*(float)prevSize.getHeight()/prevSize.getWidth()); }
                overlay.addView(tv,new FrameLayout.LayoutParams(w,h,Gravity.CENTER));
                if(front) tv.setScaleX(-1f);
                act.addContentView(overlay,new ViewGroup.LayoutParams(-1,-1));
                tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
                    boolean opened=false;
                    @Override public void onSurfaceTextureAvailable(SurfaceTexture st,int w2,int h2){ if(!opened){ opened=true; openCam(cm); } }
                    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w2,int h2){}
                    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st){ return true; }
                    @Override public void onSurfaceTextureUpdated(SurfaceTexture st){}
                });
            });
        }catch(Exception e){ fail("कैमरा चालू नहीं हुआ"); }
    }

    private void openCam(CameraManager cm){
        try{
            cm.openCamera(camId,new CameraDevice.StateCallback(){
                @Override public void onOpened(CameraDevice c){ cam=c; startSession(); }
                @Override public void onDisconnected(CameraDevice c){ fail("कैमरा बंद हो गया"); }
                @Override public void onError(CameraDevice c,int e){ fail("कैमरा एरर "+e); }
            },bg);
        }catch(Exception e){ fail("कैमरा नहीं खुला"); }
    }

    private void startSession(){
        try{
            SurfaceTexture st=tv.getSurfaceTexture();
            st.setDefaultBufferSize(prevSize.getWidth(),prevSize.getHeight());
            final Surface ps=new Surface(st);
            reader=ImageReader.newInstance(jpegSize.getWidth(),jpegSize.getHeight(),ImageFormat.JPEG,2);
            reader.setOnImageAvailableListener(r -> {
                Image img=null;
                try{
                    img=r.acquireLatestImage();
                    if(img==null) return;
                    ByteBuffer b=img.getPlanes()[0].getBuffer();
                    byte[] by=new byte[b.remaining()]; b.get(by);
                    save(by);
                }catch(Exception e){ fail("फोटो सेव नहीं हुई"); }
                finally{ if(img!=null) img.close(); }
            },bg);
            cam.createCaptureSession(Arrays.asList(ps,reader.getSurface()),new CameraCaptureSession.StateCallback(){
                @Override public void onConfigured(CameraCaptureSession s){
                    session=s;
                    try{
                        CaptureRequest.Builder pb=cam.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        pb.addTarget(ps);
                        pb.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                        pb.set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON);
                        s.setRepeatingRequest(pb.build(),null,bg);
                        act.runOnUiThread(() -> cb.ready());
                    }catch(Exception e){ fail("प्रीव्यू नहीं चला"); }
                }
                @Override public void onConfigureFailed(CameraCaptureSession s){ fail("कैमरा सेटअप नहीं हुआ"); }
            },bg);
        }catch(Exception e){ fail("कैमरा सेटअप नहीं हुआ"); }
    }

    void capture(){
        if(session==null||captured||closed) return;
        captured=true;
        try{
            CaptureRequest.Builder b=cam.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(reader.getSurface());
            b.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            b.set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON);
            int rot=act.getWindowManager().getDefaultDisplay().getRotation()*90;
            int jo=front?(sensor+rot)%360:(sensor-rot+360)%360;
            b.set(CaptureRequest.JPEG_ORIENTATION,jo);
            session.capture(b.build(),null,bg);
        }catch(Exception e){ fail("फोटो नहीं खिंची"); }
    }

    private void save(byte[] bytes) throws Exception {
        String name="MAYA_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".jpg";
        Uri uri; String path;
        if(Build.VERSION.SDK_INT>=29){
            ContentValues v=new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME,name);
            v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Maya");
            uri=act.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
            OutputStream os=act.getContentResolver().openOutputStream(uri);
            os.write(bytes); os.close();
            path="Pictures/Maya/"+name;
        } else {
            File dir=act.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES);
            File f=new File(dir,name);
            FileOutputStream fo=new FileOutputStream(f); fo.write(bytes); fo.close();
            uri=Uri.fromFile(f); path=f.getAbsolutePath();
        }
        final Uri u=uri; final String p=path;
        close();
        act.runOnUiThread(() -> cb.done(u,p));
    }

    private void fail(final String why){
        if(closed) return;
        close();
        act.runOnUiThread(() -> cb.fail(why));
    }

    void cancel(){ close(); }

    private synchronized void close(){
        if(closed) return;
        closed=true;
        try{ if(session!=null) session.close(); }catch(Exception ignored){}
        try{ if(cam!=null) cam.close(); }catch(Exception ignored){}
        try{ if(reader!=null) reader.close(); }catch(Exception ignored){}
        try{ if(th!=null) th.quitSafely(); }catch(Exception ignored){}
        act.runOnUiThread(() -> {
            try{ if(overlay!=null&&overlay.getParent()!=null) ((ViewGroup)overlay.getParent()).removeView(overlay); }catch(Exception ignored){}
        });
    }
}
