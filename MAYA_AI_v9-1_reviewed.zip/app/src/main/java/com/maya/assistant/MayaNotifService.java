package com.maya.assistant;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class MayaNotifService extends NotificationListenerService {
    private static final ArrayList<StatusBarNotification> RECENT=new ArrayList<>();
    private static final HashSet<String> PKGS=new HashSet<>(Arrays.asList(
        "com.whatsapp","com.whatsapp.w4b","org.telegram.messenger","com.instagram.android",
        "com.google.android.apps.messaging","com.android.mms","com.facebook.orca"));

    @Override public void onNotificationPosted(StatusBarNotification sbn){
        if(sbn==null||!PKGS.contains(sbn.getPackageName())) return;
        Notification n=sbn.getNotification();
        if(n==null||(n.flags&Notification.FLAG_GROUP_SUMMARY)!=0) return;
        CharSequence text=n.extras.getCharSequence(Notification.EXTRA_TEXT);
        if(text==null) return;
        synchronized(RECENT){
            RECENT.add(0,sbn);
            while(RECENT.size()>15) RECENT.remove(RECENT.size()-1);
        }
    }
    static List<StatusBarNotification> top(int n){
        synchronized(RECENT){ return new ArrayList<>(RECENT.subList(0,Math.min(n,RECENT.size()))); }
    }
    static StatusBarNotification latest(){
        synchronized(RECENT){ return RECENT.isEmpty()?null:RECENT.get(0); }
    }
    static String appName(String pkg){
        if(pkg.startsWith("com.whatsapp")) return "WhatsApp";
        if(pkg.equals("org.telegram.messenger")) return "Telegram";
        if(pkg.equals("com.instagram.android")) return "Instagram";
        if(pkg.equals("com.facebook.orca")) return "Messenger";
        return "मैसेज";
    }
    static String who(StatusBarNotification s){
        CharSequence t=s.getNotification().extras.getCharSequence(Notification.EXTRA_TITLE);
        return t==null?"भेजने वाले":t.toString();
    }
    static String describe(StatusBarNotification s){
        CharSequence x=s.getNotification().extras.getCharSequence(Notification.EXTRA_TEXT);
        return appName(s.getPackageName())+" पर "+who(s)+" ने लिखा: "+(x==null?"":x.toString())+"।";
    }
}
