package com.maya.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO=71, REQ_CAMERA=72, REQ_PHONE=73, REQ_ALL=74;
    private static final int P_NONE=0,P_CHOOSE=1,P_CALL_CONFIRM=2,P_REPLY_TEXT=3,P_REPLY_LANG=4,P_REPLY_CONFIRM=5,
            P_TERMUX=6,P_WA_BODY=7,P_WA_CONFIRM=8,P_NAME=9,P_ANSWER=10;
    private final String[] featureNames = {
            "Existing Voice Assets (preserve; not bundled)",
            "Fast Response Engine",
            "Maya Wake Phrase",
            "Focus / DND Mode",
            "Offline Command Mode",
            "Smart Network Fallback",
            "Hindi / Hinglish Support",
            "Indian Languages",
            "Google Search",
            "Chrome & Website Launcher",
            "Telegram File Finder",
            "Telegram Download / Open",
            "Telegram Join / Message",
            "WhatsApp Notification Reader",
            "WhatsApp Reply Drafts",
            "Contact Search / Disambiguation",
            "Call Helper",
            "Incoming Call Answer Assist",
            "Maps / Location",
            "YouTube Channel Assistant",
            "YouTube SEO / Keyword Research",
            "Video Review",
            "YouTube Upload / Studio",
            "APK Manager",
            "File Manager / OCR",
            "Camera / Gallery",
            "Phone Settings Dashboard",
            "Termux Command Coach",
            "Error Diagnosis / Recovery",
            "Diagnostics / Backup / Regression",
            "IMPORTANT CALL NUMBERS",
            "Website Builder & Publisher",
            "App & Website Quick Launcher",
            "Caller Screening & Spam Warning",
            "Feature Controls & Permission Center",
            "Voice-First Universal Coding Assistant",
            "Emergency Cyber Defence"
    };
    private SharedPreferences prefs;
    private LinearLayout base;
    private OrbView orb;
    private IconButton micBtn, moonBtn, aiBtn;
    private TextView status, transcript;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean listening=false, speaking=false, userStopped=false, micOn=false, quiet=false, ttsReady=false;
    private boolean streamOpen=false, beepMuted=false, pendingFront=false;
    private int page=0, speakGen=0, utts=0;
    private final StringBuilder silentBuf=new StringBuilder();
    private final android.os.Handler ui=new android.os.Handler(android.os.Looper.getMainLooper());
    private final java.util.concurrent.ExecutorService ttsExec=java.util.concurrent.Executors.newSingleThreadExecutor();
    private android.media.AudioTrack curTrack;
    private android.media.AudioManager am;
    private long offlineUntil=0;
    private volatile long ttsFailUntil=0;
    private volatile byte[][] ackPcm=null;
    private String ackSig="";
    private boolean ackLoading=false, ackPending=false;
    private int ackIdx=0;
    private long lastSpoke=0;
    private boolean fastVoice=false, voiceTest=false, partialHandled=false;
    private String lastTtsError="", workingTts="", workingChat="";
    private int waTries=0;
    private CameraShot shot;
    private String ringNum="";
    private final ArrayList<String[]> hist=new ArrayList<>();
    private int pend=P_NONE;
    private String pendKind="", pendA="", pendB="", pendC="";
    private final ArrayList<String[]> pendList=new ArrayList<>();
    private final HashMap<String,String> defs=new HashMap<>();
    private EditText apiField;
    private int wizard=-1;
    private boolean inCall=false, installRunning=false, installClicked=false;
    private int installTries=0;
    private long lastRing=0;
    private String installTerm="", lastVoiceTag="";
    private android.net.ConnectivityManager.NetworkCallback netCb;
    private final android.content.BroadcastReceiver phoneRx=new android.content.BroadcastReceiver(){
        @Override public void onReceive(android.content.Context ctx,Intent in){
            String st=in.getStringExtra(android.telephony.TelephonyManager.EXTRA_STATE);
            if(st==null) return;
            if(st.equals(android.telephony.TelephonyManager.EXTRA_STATE_RINGING)){
                onRinging(in.getStringExtra(android.telephony.TelephonyManager.EXTRA_INCOMING_NUMBER));
            } else if(st.equals(android.telephony.TelephonyManager.EXTRA_STATE_OFFHOOK)){
                inCall=true; speakGen++; speaking=false; utts=0; stopOutput(); stopListening(); clearPending();
            } else {
                inCall=false; if(pend==P_ANSWER) clearPending();
                ui.postDelayed(() -> { if(keepListening()&&!listening&&!speaking) startListening(); },1200);
            }
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,11,10));
        getWindow().setNavigationBarColor(Color.rgb(7,11,10));
        prefs=getSharedPreferences("maya_preferences", MODE_PRIVATE);
        for(S st:SETTINGS) if(!st.type.equals("head")) defs.put(st.key,st.def);
        am=(android.media.AudioManager)getSystemService(AUDIO_SERVICE);
        tts=new TextToSpeech(this, result -> {
            if(result==TextToSpeech.SUCCESS){
                ttsReady=true; applySettings();
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener(){
                    @Override public void onStart(String id){}
                    @Override public void onDone(String id){ final int g=genOf(id); ui.post(() -> chunkDone(g)); }
                    @Override public void onError(String id){ final int g=genOf(id); ui.post(() -> chunkDone(g)); }
                });
            }
        });
        showHome(); applySettings(); registerSystemListeners();
        ui.postDelayed(() -> prefetchAck(),2500);
        if(!prefs.getBoolean("wizard_done",false)) ui.postDelayed(() -> startWizard(),1200);
        if((pb("autostart")||getIntent().getBooleanExtra("boot",false))&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){
            ui.postDelayed(() -> {
                micOn=true; updateFg();
                if(pb("greet")&&prefs.getBoolean("wizard_done",false)) speak("बॉस, मैं आपकी माया हूँ। बताइए, क्या करना है?"); else startListening();
            },700);
        }
    }
    private int genOf(String id){ try{ return Integer.parseInt(id.substring(1)); }catch(Exception e){ return -1; } }

    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }
    private GradientDrawable bg(int color, int stroke, int radius){
        GradientDrawable d=new GradientDrawable(); d.setColor(color);
        d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke);
        return d;
    }
    private TextView label(String s,float size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); return t;
    }
    private LinearLayout column(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private LinearLayout.LayoutParams lp(int w,int h){
        return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));
    }

    private void showHome(){
        page=0;
        FrameLayout frame=new FrameLayout(this);
        frame.setBackgroundColor(Color.rgb(7,11,10));
        EdgeGlow edge=new EdgeGlow(this);
        frame.addView(edge,new FrameLayout.LayoutParams(-1,-1));
        base=column(); base.setPadding(dp(14),dp(12),dp(14),dp(14));
        frame.addView(base,new FrameLayout.LayoutParams(-1,-1));
        frame.setOnApplyWindowInsetsListener((v,ins)->{
            base.setPadding(dp(14),dp(12)+ins.getSystemWindowInsetTop(),dp(14),dp(14)+ins.getSystemWindowInsetBottom());
            return ins;
        });
        setContentView(frame);
        frame.requestApplyInsets();

        LinearLayout top=new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        IconButton profile=new IconButton(this,3);
        profile.setOnClickListener(v->showSettingsPage());
        aiBtn=new IconButton(this,7); aiBtn.active=pb("gemini_on");
        aiBtn.setOnClickListener(v->{
            haptic(v);
            boolean on=!pb("gemini_on");
            prefs.edit().putBoolean("s_gemini_on",on).apply();
            aiBtn.active=on; aiBtn.invalidate();
            Toast.makeText(this,on?"Gemini ON":"Gemini OFF · ऑफ़लाइन मोड (Key सुरक्षित है)",Toast.LENGTH_SHORT).show();
        });
        IconButton gear=new IconButton(this,2);
        gear.setOnClickListener(v->showMenu());
        top.addView(profile,lp(46,46));
        top.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
        top.addView(aiBtn,lp(66,44));
        top.addView(new View(this),lp(8,1));
        top.addView(gear,lp(46,46));
        base.addView(top,lp(-1,56));

        LinearLayout center=column(); center.setGravity(Gravity.CENTER);
        base.addView(center,new LinearLayout.LayoutParams(-1,0,1));
        int size=Math.min(getResources().getDisplayMetrics().widthPixels-dp(24),dp(350));
        orb=new OrbView(this);
        center.addView(orb,new LinearLayout.LayoutParams(size,size));
        status=label("",12,Color.WHITE);
        transcript=label("",12,Color.WHITE);

        LinearLayout controls=new LinearLayout(this);
        controls.setGravity(Gravity.CENTER); controls.setPadding(0,dp(8),0,dp(10));
        IconButton gal=new IconButton(this,4);
        gal.setOnClickListener(v->{ haptic(v); openGallery(); });
        IconButton selfie=new IconButton(this,5);
        selfie.setOnClickListener(v->{ haptic(v); takePhoto(true); });
        micBtn=new IconButton(this,0); micBtn.active=micOn;
        micBtn.setOnClickListener(v->{ haptic(v); toggleMic(); });
        IconButton cam=new IconButton(this,1);
        cam.setOnClickListener(v->{ haptic(v); takePhoto(false); });
        moonBtn=new IconButton(this,6); moonBtn.active=quiet;
        moonBtn.setOnClickListener(v->{ haptic(v); toggleQuiet(); });
        controls.addView(gal,lp(46,46));
        controls.addView(new View(this),lp(10,1));
        controls.addView(selfie,lp(46,46));
        controls.addView(new View(this),lp(10,1));
        controls.addView(micBtn,lp(78,78));
        controls.addView(new View(this),lp(10,1));
        controls.addView(cam,lp(46,46));
        controls.addView(new View(this),lp(10,1));
        controls.addView(moonBtn,lp(46,46));
        base.addView(controls);
    }

    // ---------- SETTINGS ----------
    private static final class S {
        final String key,title,hint,type,def; final String[] opts; final boolean wired;
        S(String key,String title,String hint,String type,String def,String[] opts,boolean wired){
            this.key=key; this.title=title; this.hint=hint; this.type=type; this.def=def; this.opts=opts; this.wired=wired;
        }
    }
    private static S head(String t){ return new S("",t,"","head","",null,true); }
    private static S tx(String k,String t,String h,String def){ return new S(k,t,h,"text",def,null,true); }
    private static S secret(String k,String t,String h){ return new S(k,t,h,"secret","",null,true); }
    private static S multi(String k,String t,String h){ return new S(k,t,h,"multi","",null,true); }
    private static S tg(String k,String t,String h,String def,boolean wired){ return new S(k,t,h,"toggle",def,null,wired); }
    private static S ch(String k,String t,String h,String def,boolean wired,String... opts){ return new S(k,t,h,"choice",def,opts,wired); }
    private static S ac(String k,String t,String h){ return new S(k,t,h,"action","",null,true); }

    private final S[] SETTINGS={
        head("प्रोफ़ाइल और AI"),
        ac("elder_mode","बुज़ुर्ग मोड (एक टैप में सही सेटिंग)","मरीज़/बुज़ुर्ग के लिए: हमेशा सुनना, धीमी आवाज़, फ़ोन चालू होते ही शुरू, कॉल आने पर बताना"),
        tx("name","आपका नाम","आपका असली नाम",""),
        tx("nick","Maya आपको क्या बुलाए","जैसे: बॉस, भाई, सर","बॉस"),
        secret("api_key","Gemini API Key","aistudio.google.com/apikey से मुफ़्त Key लेकर यहाँ डालें"),
        ac("get_key","Gemini Key लो (मुफ़्त) — पेज खोलो","aistudio.google.com/apikey पर Create API key दबाकर Key कॉपी करें"),
        ac("paste_key","कॉपी की हुई Key यहाँ पेस्ट करो","Key कॉपी करने के बाद यह दबाइए, Key अपने आप सेव हो जाएगी"),
        tg("gemini_on","Gemini चालू (होम पर AI बटन भी यही है)","बंद करने पर Key सुरक्षित रहती है और सिर्फ़ ऑफ़लाइन काम चलते हैं","true",true),
        tx("model","Gemini मॉडल का नाम","जवाब न आए तो यहाँ नया मॉडल नाम डालें","gemini-2.5-flash"),
        multi("about","मेरे बारे में (Memory)","Maya को जो हमेशा याद रखना है: काम, पसंद, शहर..."),
        ch("style","जवाब की लंबाई","","Short",true,"Short","Normal","Detailed"),
        ch("reply_lang","जवाब की भाषा","","Hindi",true,"Hindi","Hinglish","English","Marathi","Bengali","Tamil","Telugu","Gujarati","Kannada","Malayalam","Punjabi","Urdu","Odia"),
        tg("ask_lang","रिप्लाई भेजने से पहले भाषा पूछो","Gemini चालू होने पर","true",true),
        head("आवाज़"),
        tg("speak","जवाब बोलकर सुनाओ","बंद करने पर जवाब सिर्फ़ स्क्रीन पर आएगा","true",true),
        ac("tts_settings","फ़ोन की ऑफ़लाइन आवाज़ चुनें / डाउनलोड करें","अच्छी हिंदी आवाज़ के लिए Google की Hindi voice डाउनलोड करें; Maya सबसे अच्छी ऑफ़लाइन आवाज़ अपने आप चुनती है"),
        ch("voice_engine","आवाज़ का इंजन","Gemini = मीठी, भावुक आवाज़ (इंटरनेट + Key चाहिए). इंटरनेट न हो तो अपने आप Android आवाज़ चलती है","Gemini",true,"Gemini","Android"),
        ch("gvoice","Gemini आवाज़ (नाम)","Sulafat = गरम/प्यारी, Achernar = कोमल, Vindemiatrix = सौम्य, Leda = जवान, Aoede = हवादार. पुरुष: Puck, Charon, Fenrir","Sulafat",true,"Sulafat","Achernar","Vindemiatrix","Leda","Aoede","Kore","Zephyr","Puck","Charon","Fenrir"),
        tg("ack","बात सुनते ही तुरंत \"जी बॉस\" बोलो","तुरंत छोटा जवाब, फिर काम","true",true),
        tg("greet","ऐप खुलते ही \"बॉस, मैं आपकी माया हूँ\" बोलो","","true",true),
        ch("voice_style","आवाज़ का अंदाज़","Gemini इंजन में लागू","Emotional",true,"Emotional","Sweet","Warm","Cheerful","Calm"),
        tx("tts_model","Gemini आवाज़ का मॉडल","आवाज़ न आए तो यहाँ नया नाम डालें","gemini-3.1-flash-tts-preview"),
        ac("test_voice","Gemini आवाज़ टेस्ट करो","रोबोट जैसी आवाज़ आए तो यहाँ एरर की वजह दिखेगी"),
        ac("pick_voice","फ़ोन की आवाज़ चुनो (ऑफ़लाइन)","सबसे अच्छी लड़की जैसी आवाज़ सुनकर चुनें"),
        ch("rate","बोलने की रफ़्तार","","Normal",true,"Slow","Normal","Fast"),
        ch("pitch","आवाज़ की पिच","","Normal",true,"Low","Normal","High"),
        ch("listen_lang","सुनने की भाषा","","hi-IN",true,"hi-IN","en-IN","mr-IN","bn-IN","ta-IN","te-IN","gu-IN","kn-IN","ml-IN","pa-IN","ur-IN","or-IN","en-US"),
        tg("offline_speech","ऑफ़लाइन सुनना (फ़ोन में भाषा पैक चाहिए)","","false",true),
        tg("mute_beep","माइक की बीप / कट-कट आवाज़ बंद करो","माइक चालू रहते notification की आवाज़ बंद रहेगी","true",true),
        tg("continuous","जवाब के बाद माइक चालू रखो","","true",true),
        tg("autostart","ऐप खुलते ही माइक चालू","","true",true),
        tg("wake","हमेशा \"माया\" सुनकर ही जवाब दो","चालू करने पर बिना \"माया\" बोले जवाब नहीं देगी","false",true),
        head("लुक"),
        tg("edge_on","किनारे की रंगीन लाइट","","true",true),
        ch("edge_thick","लाइट की मोटाई","","Normal",true,"Thin","Normal","Thick"),
        ch("edge_speed","लाइट के घूमने की रफ़्तार","","Normal",true,"Slow","Normal","Fast"),
        ch("orb_speed","ऑर्ब की रफ़्तार","","Normal",true,"Slow","Normal","Fast"),
        tg("orb_text","ऑर्ब में MAYA लिखा दिखाओ","","true",true),
        tg("keep_on","स्क्रीन चालू रखो","","true",true),
        tg("haptic","बटन दबाने पर हल्का कंपन","","true",true),
        ch("theme","ऑर्ब का रंग","Auto = हालत के हिसाब से बदलता है","Auto",true,"Auto","Green","Blue","Purple","Rainbow"),
        head("बैकग्राउंड और फ़ोन"),
        tg("bg_service","बैकग्राउंड में चलती रहो (notification दिखेगा)","","true",true),
        tg("boot","फ़ोन चालू होने पर MAYA की सूचना","Android पाबंदियों के कारण सूचना टैप करने पर MAYA खुलेगी; माइक्रोफ़ोन अपने आप बैकग्राउंड में शुरू नहीं होगा","true",true),
        ac("overlay","दूसरे ऐप के ऊपर दिखने की अनुमति","बैकग्राउंड से ऐप खोलने के लिए ज़रूरी"),
        ac("access","Accessibility चालू करें (स्क्रीन पर बटन दबाना, अपने आप इंस्टॉल)","खुलने वाली लिस्ट में Maya को ON करें"),
        ac("battery","बैटरी पाबंदी हटाओ","Vivo में Maya को Unrestricted करें, ताकि बैकग्राउंड में बंद न हो"),
        ac("notif_access","WhatsApp/Telegram मैसेज पढ़ने की अनुमति","खुलने वाली लिस्ट में Maya को ON करें"),
        ac("perm_phone","कॉन्टैक्ट + कॉल + Termux की अनुमति दें","कॉन्टैक्ट खोजना, कॉल करना/उठाना, Termux कमांड"),
        tg("cut_company","कंपनी / टेलीमार्केटिंग के कॉल अपने आप काट दो","140, 160, 1800 जैसे नंबर; काटकर बता देगी","true",true),
        tg("call_announce","कॉल आने पर बोलकर बताओ और पूछो कि उठाऊँ?","","true",true),
        tg("auto_answer","कॉल अपने आप उठा लो (देखभाल करने वाले के लिए)","बताने के 2 सेकंड बाद उठा लेगी","false",true),
        tx("cc","देश कोड (WhatsApp नंबर के लिए)","भारत = 91","91"),
        tx("sos_number","आपातकालीन (SOS) नंबर","\"बचाओ\" या \"SOS\" बोलने पर इसी नंबर पर कॉल जाएगी (खाली = 112)",""),
        ac("setup_wizard","सेटअप गाइड (सारी अनुमतियाँ एक-एक करके)","नए फ़ोन में पहली बार ज़रूर चलाएँ"),
        head("सुरक्षा और डेटा"),
        tg("confirm","कॉल या मैसेज से पहले पूछो","","true",true),
        tg("history","बातचीत याद रखो (इस सेशन में)","","true",true),
        tg("online","इंटरनेट / Gemini इस्तेमाल करो","","true",true),
        tg("mask_key","API Key छिपाकर दिखाओ","","true",true),
        tg("safe","सेफ़ मोड: वॉइस से ऐप न खोलो","","false",true),
        tg("showheard","जो सुना वह स्क्रीन पर दिखाओ","","false",true),
        ac("unmute_all","आवाज़ वापस चालू करो (अगर बंद रह गई हो)",""),
        ac("clear_mem","Memory (मेरे बारे में) मिटाओ","सिर्फ़ \"मेरे बारे में\" वाला टेक्स्ट हटेगा"),
        ac("reset","सारी सेटिंग रीसेट करो","API Key और नाम भी हट जाएँगे")
    };

    private static final String[][] LANGS={{"Hindi","hi-IN"},{"Hinglish","hi-IN"},{"English","en-IN"},{"Marathi","mr-IN"},
        {"Bengali","bn-IN"},{"Tamil","ta-IN"},{"Telugu","te-IN"},{"Gujarati","gu-IN"},{"Kannada","kn-IN"},
        {"Malayalam","ml-IN"},{"Punjabi","pa-IN"},{"Urdu","ur-IN"},{"Odia","or-IN"}};
    private String langTag(String name){ for(String[] l:LANGS) if(l[0].equals(name)) return l[1]; return "hi-IN"; }

    private String ps(String k){ return prefs.getString("s_"+k,defs.containsKey(k)?defs.get(k):""); }
    private boolean pb(String k){ return prefs.getBoolean("s_"+k,"true".equals(defs.get(k))); }
    private float pick(String k,float a,float b,float c){
        String v=ps(k);
        if(v.equals("Slow")||v.equals("Thin")||v.equals("Low")) return a;
        if(v.equals("Fast")||v.equals("Thick")||v.equals("High")) return c;
        return b;
    }
    private String callName(){
        String n=ps("nick").trim(); if(n.isEmpty()) n=ps("name").trim();
        if(n.isEmpty()||n.equalsIgnoreCase("boss")) return "बॉस";
        return n;
    }
    private boolean keepListening(){ return micOn&&(pb("continuous")||quiet||pend!=P_NONE); }
    private void haptic(View v){ if(pb("haptic")) v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP); }
    private void applySettings(){
        if(pb("keep_on")) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if(ttsReady&&tts!=null){
            try{ tts.setLanguage(Locale.forLanguageTag(langTag(ps("reply_lang")))); }catch(Exception ignored){}
            String tag=langTag(ps("reply_lang"));
            if(!tag.equals(lastVoiceTag)){ lastVoiceTag=tag; pickBestVoice(tag); }
            tts.setSpeechRate(pick("rate",.85f,1f,1.3f));
            float sweet=ps("voice_style").equals("Sweet")?1.08f:1f;
            tts.setPitch(pick("pitch",.85f,1f,1.2f)*sweet);
        }
    }
    @Override protected void onResume(){ super.onResume(); if(wizard>1) ui.postDelayed(() -> nextWizard(),700); }
    @Override protected void onPause(){ super.onPause(); if(shot!=null){ shot.cancel(); shot=null; } }
    @Override protected void onStart(){ super.onStart(); prefetchAck(); }
    @Override public void onBackPressed(){ if(shot!=null){ shot.cancel(); shot=null; return; } if(page!=0) showHome(); else super.onBackPressed(); }

    // ---------- SETTINGS PAGE ----------
    private void showSettingsPage(){
        page=1;
        final LinearLayout root=column(); root.setBackgroundColor(Color.rgb(7,11,10));
        root.setOnApplyWindowInsetsListener((v,ins)->{
            root.setPadding(0,ins.getSystemWindowInsetTop(),0,ins.getSystemWindowInsetBottom());
            return ins;
        });
        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL); head.setPadding(dp(8),dp(8),dp(16),dp(8));
        TextView back=label("←",26,0xffb8f4d0); back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v->showHome());
        head.addView(back,lp(52,48));
        TextView ttl=label("SETTINGS · "+countSettings(),19,Color.WHITE); ttl.setTypeface(null,Typeface.BOLD);
        head.addView(ttl,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(head);
        ScrollView sc=new ScrollView(this);
        LinearLayout list=column(); list.setPadding(dp(18),dp(2),dp(18),dp(40));
        sc.addView(list);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        apiField=null;
        int num=0;
        for(S st:SETTINGS){
            if(st.type.equals("head")){
                TextView hd=label(st.title,12,0xff63f5a5); hd.setLetterSpacing(.14f); hd.setPadding(0,dp(22),0,dp(4));
                list.addView(hd); continue;
            }
            num++;
            list.addView(settingRow(st,num));
        }
        setContentView(root);
        root.requestApplyInsets();
    }
    private EditText styledInput(String hint){
        EditText et=new EditText(this);
        et.setTextColor(Color.WHITE); et.setHintTextColor(0xff5d786a); et.setTextSize(14); et.setHint(hint);
        et.setBackground(bg(0xff0a110e,0xff28523d,10));
        et.setPadding(dp(12),dp(10),dp(12),dp(10));
        return et;
    }
    private View settingRow(final S st,int num){
        LinearLayout row=column(); row.setPadding(dp(14),dp(12),dp(14),dp(12));
        row.setBackground(bg(0xff0e1713,0xff1d3328,14));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.topMargin=dp(8);
        row.setLayoutParams(rp);
        String title=String.format(Locale.ROOT,"%02d  %s",num,st.title);
        if(st.type.equals("toggle")){
            Switch sw=new Switch(this); sw.setText(title); sw.setTextColor(0xfff0f7f3); sw.setTextSize(14.5f);
            sw.setChecked(pb(st.key));
            sw.setOnCheckedChangeListener((b,on)->{
                prefs.edit().putBoolean("s_"+st.key,on).apply();
                applySettings();
                if(st.key.equals("mask_key")&&apiField!=null) applyKeyMask();
            });
            row.addView(sw);
        } else {
            row.addView(label(title,14.5f,0xfff0f7f3));
        }
        if(!st.hint.isEmpty()){
            TextView h=label(st.hint,11,0xff7f9b8c); h.setPadding(0,dp(3),0,0); row.addView(h);
        }
        if(!st.wired){
            TextView soon=label("जल्द आएगा — अभी सिर्फ़ सेव होता है",11,0xffffb02e); soon.setPadding(0,dp(3),0,0); row.addView(soon);
        }
        if(st.type.equals("text")||st.type.equals("secret")||st.type.equals("multi")){
            final EditText et=styledInput(st.title);
            if(st.type.equals("multi")){
                et.setMinLines(3); et.setGravity(Gravity.TOP|Gravity.START);
                et.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            } else if(st.type.equals("secret")){
                apiField=et; applyKeyMask();
            } else {
                et.setSingleLine(true);
            }
            et.setText(prefs.getString("s_"+st.key,defs.containsKey(st.key)?defs.get(st.key):""));
            et.addTextChangedListener(new android.text.TextWatcher(){
                public void beforeTextChanged(CharSequence a,int b,int c,int d){}
                public void onTextChanged(CharSequence a,int b,int c,int d){}
                public void afterTextChanged(android.text.Editable e){ prefs.edit().putString("s_"+st.key,e.toString()).apply(); }
            });
            LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,-2); ep.topMargin=dp(8);
            row.addView(et,ep);
        } else if(st.type.equals("choice")){
            final TextView val=label("▸ "+ps(st.key),14,0xff63f5a5); val.setPadding(0,dp(6),0,0);
            row.addView(val);
            row.setOnClickListener(v->new AlertDialog.Builder(this).setTitle(st.title).setItems(st.opts,(d,w)->{
                prefs.edit().putString("s_"+st.key,st.opts[w]).apply();
                val.setText("▸ "+st.opts[w]);
                applySettings();
            }).show());
        } else if(st.type.equals("action")){
            TextView go=label("▸ चलाएँ",14,0xff63f5a5); go.setPadding(0,dp(6),0,0);
            row.addView(go);
            row.setOnClickListener(v->doAction(st.key));
        }
        return row;
    }
    private void applyKeyMask(){
        if(apiField==null) return;
        int type=android.text.InputType.TYPE_CLASS_TEXT|(pb("mask_key")
            ?android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            :android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        apiField.setInputType(type);
        apiField.setSelection(apiField.getText().length());
    }
    private int countSettings(){ int n=0; for(S st:SETTINGS) if(!st.type.equals("head")) n++; return n; }
    private void doAction(String key){
        try{
        if(key.equals("battery")){
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        } else if(key.equals("overlay")){
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));
        } else if(key.equals("notif_access")){
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        } else if(key.equals("perm_phone")){
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS,Manifest.permission.CALL_PHONE,
                Manifest.permission.ANSWER_PHONE_CALLS,Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_CALL_LOG,"android.permission.POST_NOTIFICATIONS","com.termux.permission.RUN_COMMAND"},REQ_PHONE);
        } else if(key.equals("access")){
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        } else if(key.equals("tts_settings")){
            try{ startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }catch(Exception e2){ startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        } else if(key.equals("elder_mode")){
            prefs.edit().putBoolean("s_autostart",true).putBoolean("s_continuous",true).putBoolean("s_speak",true).putBoolean("s_bg_service",true)
                .putBoolean("s_keep_on",true).putBoolean("s_boot",true).putBoolean("s_call_announce",true).putBoolean("s_wake",false)
                .putString("s_rate","Slow").putString("s_style","Short").apply();
            applySettings();
            Toast.makeText(this,"बुज़ुर्ग मोड चालू। बैटरी, ऊपर दिखना, Notification access और Accessibility की अनुमतियाँ एक बार ज़रूर दें।",Toast.LENGTH_LONG).show();
            showSettingsPage();
        } else if(key.equals("get_key")){
            openUrl("https://aistudio.google.com/apikey");
        } else if(key.equals("paste_key")){
            pasteKey(true);
        } else if(key.equals("test_voice")){
            testVoice();
        } else if(key.equals("pick_voice")){
            chooseVoice();
        } else if(key.equals("setup_wizard")){
            startWizard();
        } else if(key.equals("unmute_all")){
            muteBeep(false);
            for(int s:new int[]{android.media.AudioManager.STREAM_MUSIC,android.media.AudioManager.STREAM_NOTIFICATION,android.media.AudioManager.STREAM_SYSTEM})
                am.adjustStreamVolume(s,android.media.AudioManager.ADJUST_UNMUTE,0);
            Toast.makeText(this,"आवाज़ वापस चालू कर दी",Toast.LENGTH_SHORT).show();
        } else if(key.equals("clear_mem")){
            new AlertDialog.Builder(this).setTitle("Memory मिटाएँ?").setMessage("\"मेरे बारे में\" का टेक्स्ट हट जाएगा।")
                .setPositiveButton("हाँ",(d,w)->{ prefs.edit().remove("s_about").apply(); showSettingsPage(); })
                .setNegativeButton("नहीं",null).show();
        } else if(key.equals("reset")){
            new AlertDialog.Builder(this).setTitle("सारी सेटिंग रीसेट करें?").setMessage("API Key, नाम और सारी सेटिंग हट जाएँगी।")
                .setPositiveButton("हाँ",(d,w)->{ prefs.edit().clear().apply(); applySettings(); showSettingsPage(); })
                .setNegativeButton("नहीं",null).show();
        }
        }catch(Exception e){ Toast.makeText(this,"यह स्क्रीन नहीं खुल सकी: फ़ोन की Settings में खुद खोलें",Toast.LENGTH_LONG).show(); }
    }

    // ---------- STATE / MIC ----------
    private void setMode(String mode,String message){
        if(status!=null) status.setText(message);
        if(orb!=null){ orb.mode=mode; orb.invalidate(); }
        if(micBtn!=null){ micBtn.active=micOn||listening; micBtn.invalidate(); }
        if(moonBtn!=null){ moonBtn.active=quiet; moonBtn.invalidate(); }
        if(message!=null&&(message.contains("NOT AVAILABLE")||message.contains("COULD NOT")||message.contains("PERMISSION")))
            Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }
    private void muteBeep(boolean mute){
        if(am==null) return;
        if(mute&&!pb("mute_beep")) mute=false;
        if(mute==beepMuted) return;
        int[] st={android.media.AudioManager.STREAM_NOTIFICATION,android.media.AudioManager.STREAM_SYSTEM};
        for(int s:st){
            try{ am.adjustStreamVolume(s,mute?android.media.AudioManager.ADJUST_MUTE:android.media.AudioManager.ADJUST_UNMUTE,0); }catch(Exception ignored){}
        }
        beepMuted=mute;
    }
    private void blipMusic(int ms){
        if(am==null||!pb("mute_beep")) return;
        try{
            if(am.isMusicActive()) return;
            am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,android.media.AudioManager.ADJUST_MUTE,0);
            ui.postDelayed(() -> { try{ am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,android.media.AudioManager.ADJUST_UNMUTE,0); }catch(Exception ignored){} },ms);
        }catch(Exception ignored){}
    }
    private void updateFg(){
        try{
            Intent i=new Intent(this,MayaFgService.class);
            if(micOn&&pb("bg_service")){
                if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            } else stopService(i);
        }catch(Exception ignored){}
    }
    private void toggleMic(){
        if(micOn||listening){
            micOn=false; userStopped=true; stopListening(); muteBeep(false); updateFg();
            setMode(quiet?"quiet":"idle","MICROPHONE OFF"); return;
        }
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_AUDIO); return;
        }
        if(android.os.Build.VERSION.SDK_INT>=33&&!prefs.getBoolean("asked_notif",false)){
            prefs.edit().putBoolean("asked_notif",true).apply();
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},REQ_PHONE);
        }
        micOn=true; updateFg(); startListening();
    }
    private void startListening(){
        if(listening||speaking||inCall) return;
        if(!SpeechRecognizer.isRecognitionAvailable(this)){ micOn=false; setMode("idle","SPEECH SERVICE NOT AVAILABLE"); return; }
        try{
            if(recognizer!=null){ recognizer.destroy(); recognizer=null; }
            recognizer=SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener(){
                public void onReadyForSpeech(Bundle p){ listening=true; setMode(quiet?"quiet":"listen","LISTENING"); }
                public void onBeginningOfSpeech(){}
                public void onRmsChanged(float v){}
                public void onBufferReceived(byte[] b){}
                public void onEndOfSpeech(){ listening=false; blipMusic(700); if(!quiet) setMode("think","ONE MOMENT"); }
                public void onPartialResults(Bundle b){
                    ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(a==null||a.isEmpty()||partialHandled) return;
                    if(isFastCommand(norm(a.get(0)))){
                        partialHandled=true; stopListening();
                        transcript.setText(a.get(0));
                        handleCommand(a.get(0));
                        if(!speaking) restartSoon();
                    }
                }
                public void onEvent(int t,Bundle b){}
                public void onError(int e){
                    listening=false; blipMusic(500);
                    if(e==SpeechRecognizer.ERROR_CLIENT) return;
                    if(e==SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS){
                        micOn=false; muteBeep(false); updateFg(); setMode("idle","MIC PERMISSION NEEDED"); return;
                    }
                    if(keepListening()&&!userStopped&&!speaking){
                        setMode(quiet?"quiet":"idle","LISTENING AGAIN");
                        long delay=(e==SpeechRecognizer.ERROR_RECOGNIZER_BUSY)?900:250;
                        ui.postDelayed(() -> { if(keepListening()&&!listening&&!speaking&&!userStopped) startListening(); },delay);
                    } else if(!userStopped&&!speaking){
                        micOn=false; muteBeep(false); updateFg(); setMode("idle","TAP MIC TO TRY AGAIN");
                    }
                }
                public void onResults(Bundle b){
                    listening=false; blipMusic(500);
                    if(partialHandled) return;
                    ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String heard=(a!=null&&!a.isEmpty())?a.get(0):"";
                    if(heard.trim().isEmpty()){ restartSoon(); return; }
                    transcript.setText(heard);
                    handleCommand(heard);
                }
            });
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,ps("listen_lang"));
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,ps("listen_lang"));
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,pb("offline_speech"));
            i.putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS",900);
            i.putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS",700);
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
            userStopped=false; partialHandled=false;
            muteBeep(true); blipMusic(900);
            recognizer.startListening(i);
        }catch(Exception e){ setMode("idle","COULD NOT START MICROPHONE"); }
    }
    private void stopListening(){
        listening=false;
        if(recognizer!=null){ try{ recognizer.stopListening(); recognizer.cancel(); }catch(Exception ignored){} }
    }
    private boolean isFastCommand(String q){
        if(pend!=P_NONE||quiet) return false;
        boolean app=has(q,"whatsapp","youtube","chrome","telegram","instagram","facebook","gallery","settings","calculator","maps","gmail","phonepe","snapchat","play store","termux","camera");
        return (app&&has(q,"खोल","open","चालू करो"))||has(q,"फोटो खींच","सेल्फी","selfie");
    }
    private void restartSoon(){
        if(keepListening()) ui.post(() -> { if(keepListening()&&!listening&&!speaking) startListening(); });
    }

    // ---------- SPEECH OUTPUT (chunked, fast) ----------
    private void beginSpeak(){
        speaking=true; streamOpen=true; speakGen++; utts=0; silentBuf.setLength(0); lastSpoke=System.currentTimeMillis();
        stopOutput();
        setMode("speak","MAYA IS SPEAKING");
        final int g=speakGen;
        ui.postDelayed(() -> { if(g==speakGen&&speaking){ utts=0; streamOpen=false; afterSpeak(); } },90000);
    }
    private void stopOutput(){
        try{ if(tts!=null) tts.stop(); }catch(Exception ignored){}
        AudioTrackHolder.stop(curTrack); curTrack=null;
    }
    private void speak(String s){ beginSpeak(); speakChunk(s); endSpeak(); }
    private void speakFast(String s){ fastVoice=true; try{ speak(s); }finally{ fastVoice=false; } }
    private void speakChunk(String text){
        String tt=text.replaceAll("[*#`_>]","").trim();
        if(tt.isEmpty()) return;
        if(ackPending){ tt="जी "+callName()+", "+tt; ackPending=false; }
        final String t=tt;
        if(!pb("speak")){ if(silentBuf.length()>0) silentBuf.append(' '); silentBuf.append(t); return; }
        utts++;
        final int g=speakGen;
        if(utts==1) setMode("speak","MAYA IS SPEAKING");
        if(!fastVoice&&System.currentTimeMillis()>=ttsFailUntil&&ps("voice_engine").equals("Gemini")&&pb("gemini_on")&&pb("online")&&!ps("api_key").trim().isEmpty()&&online()){
            ttsExec.execute(() -> {
                boolean ok=false;
                try{ if(g==speakGen) ok=geminiSpeak(t,g); }catch(Exception e){ ok=false; }
                if(!ok) ttsFailUntil=System.currentTimeMillis()+60000;
                final boolean fine=ok;
                ui.post(() -> {
                    if(fine&&voiceTest){ voiceTest=false; Toast.makeText(this,"Gemini आवाज़ चालू है ✔ ("+workingTts+")",Toast.LENGTH_LONG).show(); }
                    if(!fine&&!lastTtsError.isEmpty()){ Toast.makeText(this,lastTtsError,Toast.LENGTH_LONG).show(); voiceTest=false; }
                    if(g!=speakGen) return;
                    if(fine) chunkDone(g); else androidSpeak(t,g);
                });
            });
        } else androidSpeak(t,g);
    }
    private void androidSpeak(String t,int g){
        if(tts==null||!ttsReady){ chunkDone(g); return; }
        int r=tts.speak(t,TextToSpeech.QUEUE_ADD,null,"c"+g);
        if(r!=TextToSpeech.SUCCESS) chunkDone(g);
    }
    private void endSpeak(){
        streamOpen=false;
        if(!pb("speak")&&silentBuf.length()>0) Toast.makeText(this,silentBuf.toString(),Toast.LENGTH_LONG).show();
        if(!pb("speak")) { final int g=speakGen; ui.postDelayed(() -> { if(g==speakGen) afterSpeak(); },Math.min(5000,Math.max(1200,silentBuf.length()*50))); return; }
        checkDone();
    }
    private void chunkDone(int g){ if(g!=speakGen) return; utts--; checkDone(); }
    private void checkDone(){ if(!streamOpen&&utts<=0&&speaking) afterSpeak(); }
    private void afterSpeak(){
        if(!speaking) return;
        speaking=false; utts=0; streamOpen=false;
        setMode(quiet?"quiet":"idle","TAP THE MIC TO TALK");
        if(keepListening()&&!listening) startListening();
        else if(micOn&&!pb("continuous")){ micOn=false; muteBeep(false); updateFg(); setMode(quiet?"quiet":"idle","TAP THE MIC TO TALK"); }
    }
    private boolean geminiSpeak(String text,int gen) throws Exception{
        byte[] pcm=geminiPcm(text);
        if(pcm==null) return false;
        if(gen==speakGen) playPcm(pcm,gen);
        return true;
    }
    private byte[] geminiPcm(String text) throws Exception{
        String key=ps("api_key").trim();
        ArrayList<String> models=new ArrayList<>();
        if(!workingTts.isEmpty()) models.add(workingTts);
        String um=ps("tts_model").trim(); if(!um.isEmpty()&&!models.contains(um)) models.add(um);
        for(String c:new String[]{"gemini-2.5-flash-preview-tts","gemini-3.1-flash-tts-preview","gemini-2.5-pro-preview-tts"}) if(!models.contains(c)) models.add(c);
        String voice=ps("gvoice").isEmpty()?"Sulafat":ps("gvoice");
        String st=ps("voice_style");
        String lead=st.equals("Emotional")?"Perform this as Maya, a gentle, affectionate young woman talking to someone she cares for deeply. Speak softly and warmly, with a smile in your voice, tender emotional inflection, natural breathy pauses and an unhurried pace, in natural expressive Hindi: ":st.equals("Warm")?"Say warmly and affectionately: ":st.equals("Cheerful")?"Say cheerfully: ":st.equals("Calm")?"Say calmly and softly: ":"Say in a sweet, soft, emotional and loving voice: ";
        JSONObject body=new JSONObject();
        body.put("contents",new JSONArray().put(new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",lead+text)))));
        body.put("generationConfig",new JSONObject().put("responseModalities",new JSONArray().put("AUDIO"))
            .put("speechConfig",new JSONObject().put("voiceConfig",new JSONObject().put("prebuiltVoiceConfig",new JSONObject().put("voiceName",voice)))));
        String bs=body.toString();
        for(String model:models){
            java.net.HttpURLConnection c=openGemini("models/"+model+":generateContent",key,bs);
            int code=c.getResponseCode();
            if(code>=200&&code<300){
                String resp=readAll(c.getInputStream());
                try{
                    String b64=new JSONObject(resp).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                        .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data");
                    byte[] pcm=android.util.Base64.decode(b64,android.util.Base64.DEFAULT);
                    workingTts=model; lastTtsError="";
                    return pcm;
                }catch(Exception parse){ lastTtsError="आवाज़ का जवाब समझ नहीं आया ("+model+")"; continue; }
            }
            String er=readAll(c.getErrorStream());
            String msg=""; try{ msg=new JSONObject(er).getJSONObject("error").getString("message"); }catch(Exception ignored){}
            lastTtsError="आवाज़ एरर "+code+" ("+model+"): "+(msg.length()>90?msg.substring(0,90):msg);
            if(code==404||(code==400&&!msg.toLowerCase(Locale.ROOT).contains("api key"))) continue;
            break;
        }
        return null;
    }
    private boolean geminiVoiceReady(){
        return ps("voice_engine").equals("Gemini")&&pb("gemini_on")&&pb("online")&&!ps("api_key").trim().isEmpty()&&online()&&System.currentTimeMillis()>=ttsFailUntil;
    }
    private void prefetchAck(){
        if(ackLoading||!geminiVoiceReady()) return;
        final String sig=ps("gvoice")+"|"+ps("voice_style")+"|"+callName();
        if(sig.equals(ackSig)&&ackPcm!=null) return;
        ackLoading=true; ackSig=sig; ackPcm=null;
        final String nm=callName();
        new Thread(() -> {
            try{
                String[] phr={"जी "+nm+"।","ठीक है "+nm+"।","जी "+nm+", बताइए।"};
                byte[][] out=new byte[phr.length][];
                for(int i=0;i<phr.length;i++){
                    java.io.File f=new java.io.File(getCacheDir(),"ack_"+Math.abs(sig.hashCode())+"_"+i+".pcm");
                    if(f.exists()&&f.length()>1000){
                        java.io.FileInputStream in=new java.io.FileInputStream(f);
                        java.io.ByteArrayOutputStream bo=new java.io.ByteArrayOutputStream();
                        byte[] b=new byte[4096]; int n;
                        while((n=in.read(b))>0) bo.write(b,0,n);
                        in.close(); out[i]=bo.toByteArray();
                    } else {
                        byte[] pcm=geminiPcm(phr[i]);
                        if(pcm==null) throw new Exception("ack");
                        java.io.FileOutputStream fo=new java.io.FileOutputStream(f); fo.write(pcm); fo.close();
                        out[i]=pcm;
                    }
                }
                ackPcm=out;
            }catch(Exception e){ ackSig=""; }
            finally{ ackLoading=false; }
        }).start();
    }
    private void playAck(){
        if(!pb("speak")||!pb("ack")) return;
        byte[][] a=ackPcm;
        if(a!=null&&a.length>=3&&geminiVoiceReady()){
            final byte[] b=a[(ackIdx++)%2];
            ttsExec.execute(() -> playPcmRaw(b));
        } else ackPending=true;
    }
    private boolean ackOnly(){
        byte[][] a=ackPcm;
        if(!pb("speak")||!pb("ack")||a==null||a.length<3||!geminiVoiceReady()) return false;
        final byte[] b=a[2];
        beginSpeak(); utts++;
        final int g=speakGen;
        ttsExec.execute(() -> { playPcmRaw(b); ui.post(() -> chunkDone(g)); });
        endSpeak();
        return true;
    }
    private void playPcmRaw(byte[] pcm){
        android.media.AudioTrack t=null;
        try{
            int min=android.media.AudioTrack.getMinBufferSize(24000,android.media.AudioFormat.CHANNEL_OUT_MONO,android.media.AudioFormat.ENCODING_PCM_16BIT);
            t=new android.media.AudioTrack(android.media.AudioManager.STREAM_MUSIC,24000,android.media.AudioFormat.CHANNEL_OUT_MONO,
                android.media.AudioFormat.ENCODING_PCM_16BIT,Math.max(min,16384),android.media.AudioTrack.MODE_STREAM);
            t.play();
            int off=0;
            while(off<pcm.length){ int n=t.write(pcm,off,Math.min(8192,pcm.length-off)); if(n<=0) break; off+=n; }
            int frames=pcm.length/2; long until=System.currentTimeMillis()+frames*1000L/24000+600;
            while(t.getPlaybackHeadPosition()<frames&&System.currentTimeMillis()<until){ try{ Thread.sleep(20); }catch(InterruptedException ie){ break; } }
        }catch(Exception ignored){}
        AudioTrackHolder.stop(t);
    }
    private void playPcm(byte[] pcm,int gen){
        int min=android.media.AudioTrack.getMinBufferSize(24000,android.media.AudioFormat.CHANNEL_OUT_MONO,android.media.AudioFormat.ENCODING_PCM_16BIT);
        android.media.AudioTrack t=new android.media.AudioTrack(android.media.AudioManager.STREAM_MUSIC,24000,
            android.media.AudioFormat.CHANNEL_OUT_MONO,android.media.AudioFormat.ENCODING_PCM_16BIT,Math.max(min,16384),android.media.AudioTrack.MODE_STREAM);
        curTrack=t;
        try{
            t.play();
            int off=0;
            while(off<pcm.length&&gen==speakGen){
                int n=t.write(pcm,off,Math.min(8192,pcm.length-off));
                if(n<=0) break; off+=n;
            }
            int frames=pcm.length/2; long until=System.currentTimeMillis()+frames*1000L/24000+600;
            while(gen==speakGen&&t.getPlaybackHeadPosition()<frames&&System.currentTimeMillis()<until){ try{ Thread.sleep(20); }catch(InterruptedException ie){ break; } }
        }catch(Exception ignored){}
        AudioTrackHolder.stop(t);
        if(curTrack==t) curTrack=null;
    }
    static final class AudioTrackHolder {
        static void stop(android.media.AudioTrack t){
            if(t==null) return;
            try{ t.pause(); t.flush(); }catch(Exception ignored){}
            try{ t.release(); }catch(Exception ignored){}
        }
    }
    private boolean online(){
        try{
            android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            android.net.Network n=cm.getActiveNetwork(); if(n==null) return false;
            android.net.NetworkCapabilities nc=cm.getNetworkCapabilities(n);
            return nc!=null&&nc.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
        }catch(Exception e){ return true; }
    }

    // ---------- COMMAND ROUTING ----------
    private static final String[][] ALIAS={
        {"व्हाट्सएप","whatsapp"},{"व्हाट्सऐप","whatsapp"},{"वॉट्सऐप","whatsapp"},{"वाट्सएप","whatsapp"},{"व्हाट्स ऐप","whatsapp"},{"whats app","whatsapp"},
        {"यूट्यूब","youtube"},{"यू ट्यूब","youtube"},{"क्रोम","chrome"},{"टेलीग्राम","telegram"},{"टेलिग्राम","telegram"},
        {"इंस्टाग्राम","instagram"},{"फेसबुक","facebook"},{"कैलकुलेटर","calculator"},{"कैल्कुलेटर","calculator"},
        {"जीमेल","gmail"},{"टर्मक्स","termux"},{"टर्मिनल","termux"},{"गूगल","google"},{"गैलरी","gallery"},{"कैमरा","camera"},
        {"सेटिंग्स","settings"},{"सेटिंग","settings"},{"मैप्स","maps"},{"प्ले स्टोर","play store"},{"प्लेस्टोर","play store"},
        {"स्नैपचैट","snapchat"},{"फोनपे","phonepe"},{"फोन पे","phonepe"},{"चैटजीपीटी","chatgpt"},{"वाईफाई","wifi"},{"वाई फाई","wifi"},{"ब्लूटूथ","bluetooth"},
        {"ओपन","open"},{"ओपेन","open"},{"स्टार्ट","start"},{"इंस्टाल","इंस्टॉल"},
        {"व्हाट्सअप","whatsapp"},{"वाट्सअप","whatsapp"},{"वॉट्सअप","whatsapp"},{"व्हॉट्सएप","whatsapp"},{"व्हॉट्सऐप","whatsapp"},{"व्हॉट्सअप","whatsapp"},
        {"जी मेल","gmail"},{"पेटीएम","paytm"},{"नेटफ्लिक्स","netflix"},{"ज़ूम","zoom"},{"जूम","zoom"},{"स्पॉटिफाई","spotify"},
        {"ट्रूकॉलर","truecaller"},{"अमेज़न","amazon"},{"अमेजन","amazon"},{"फ्लिपकार्ट","flipkart"},{"हॉटस्टार","hotstar"}
    };
    private String norm(String s){
        StringBuilder sb=new StringBuilder();
        for(char c:s.toLowerCase(Locale.ROOT).toCharArray()){
            if(c>='०'&&c<='९') sb.append((char)('0'+(c-'०')));
            else if(",!?।;:\"'()".indexOf(c)>=0) sb.append(' ');
            else sb.append(c);
        }
        String q=sb.toString();
        for(String[] a:ALIAS) q=q.replace(a[0],a[1]);
        return q.replaceAll("\\s+"," ").trim();
    }
    private boolean has(String q,String... ws){ for(String w:ws) if(q.contains(w)) return true; return false; }
    private boolean hw(String q,String... ws){
        for(String w:ws) if(Pattern.compile("(?<![\\p{L}\\p{M}])"+Pattern.quote(w)+"(?![\\p{L}\\p{M}])").matcher(q).find()) return true;
        return false;
    }
    private String removeWords(String q,String... ws){
        for(String w:ws) q=Pattern.compile("(?<![\\p{L}\\p{M}])"+Pattern.quote(w)+"(?![\\p{L}\\p{M}])").matcher(q).replaceAll(" ");
        return q.replaceAll("\\s+"," ").trim();
    }
    private boolean isYes(String q){
        return hw(q,"yes","ok","okay","yeah","ha","haan","han")||has(q,"हाँ","हां","ठीक है","कर दो","करो","भेज दो","भेजो","चलाओ","लगाओ","ज़रूर","जरूर");
    }
    private boolean isNo(String q){
        return hw(q,"no","nope","cancel","stop")||has(q,"नहीं","मत ","रहने दो","कैंसल","छोड़ो","रद्द");
    }
    private static final String[] WAKES={"माया","मया","मैया","maya"};
    private boolean hasWake(String q){ for(String w:WAKES) if(q.contains(w)) return true; return false; }
    private String stripWake(String q){
        for(String w:WAKES) q=q.replace(w," ");
        return q.replaceAll("\\s+"," ").trim();
    }

    private void handleCommand(String raw){
        String q=norm(raw);
        if(pb("showheard")) Toast.makeText(this,raw,Toast.LENGTH_SHORT).show();
        boolean w=hasWake(q);
        if(quiet&&pend==P_NONE){
            if(!w){ restartSoon(); return; }
            quiet=false; setMode("idle","");
            q=stripWake(q);
            if(q.isEmpty()){ if(!ackOnly()) speak("जी "+callName()+", बताइए।"); return; }
        } else if(pb("wake")&&!w&&pend==P_NONE){
            restartSoon(); return;
        } else if(w){
            q=stripWake(q);
            if(q.isEmpty()){ if(!ackOnly()) speak("जी "+callName()+", बताइए।"); return; }
        }
        if(has(q,"काम कर रहा","काम कर रही","डिस्टर्ब मत","disturb","परेशान मत","बात मत","चुप रहो","चुप हो","मत बोलो","quiet","silent")&&!has(q,"वापस","शुरू")){
            enterQuiet(); return;
        }
        if(pend!=P_NONE){ handlePending(q,raw); return; }
        playAck();
        final long t0=System.currentTimeMillis();
        ui.postDelayed(() -> { if(lastSpoke<t0&&!speaking&&!listening&&!inCall&&pend==P_NONE) speakFast("बॉस, मुझे समझ नहीं आया। दोबारा बोलिए।"); },8000);
        if(handleLocal(q,raw)) return;
        askGemini(raw);
    }
    private void toggleQuiet(){
        if(quiet){ quiet=false; setMode("idle",""); speak("जी "+callName()+", मैं वापस आ गई।"); }
        else enterQuiet();
    }
    private void enterQuiet(){
        quiet=true; clearPending();
        if(!micOn&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){ micOn=true; updateFg(); }
        speak("ठीक है "+callName()+", मैं चुप रहूँगी। ज़रूरत हो तो बस माया बोलिए।");
    }
    private void clearPending(){ pend=P_NONE; pendList.clear(); pendKind=""; pendA=""; pendB=""; pendC=""; }

    // ---------- PENDING (questions Maya asked) ----------
    private int pickIndex(String q){
        Matcher m=Pattern.compile("\\d+").matcher(q);
        if(m.find()){ try{ return Integer.parseInt(m.group())-1; }catch(Exception ignored){} }
        if(has(q,"पहला","पहले","एक","first","one")) return 0;
        if(has(q,"दूसरा","दूसरे","दो","second","two")) return 1;
        if(has(q,"तीसरा","तीन","third","three")) return 2;
        if(has(q,"चौथा","चार","four")) return 3;
        if(has(q,"पाँच","पांच","five")) return 4;
        return -1;
    }
    private void handlePending(String q,String raw){
        int p=pend;
        if(p!=P_REPLY_TEXT&&p!=P_WA_BODY&&p!=P_REPLY_LANG&&p!=P_NAME&&p!=P_ANSWER&&isNo(q)&&!isYes(q)){ clearPending(); speak("ठीक है, रद्द कर दिया।"); return; }
        switch(p){
            case P_NAME: {
                String nm=removeWords(q,"माया","maya","जी","नाम");
                if(nm.isEmpty()){ speak("नाम बोलिए।"); return; }
                findAndChoose(nm); return;
            }
            case P_CHOOSE: {
                int idx=pickIndex(q);
                if(idx<0){
                    String sk=skeleton(q);
                    for(int i=0;i<pendList.size();i++) if(sk.length()>=2&&skeleton(pendList.get(i)[0]).contains(sk)){ idx=i; break; }
                }
                if(idx<0||idx>=pendList.size()){ speak("समझ नहीं आया। 1 से "+pendList.size()+" में से नंबर बोलिए, या रहने दो बोलिए।"); return; }
                afterPick(pendList.get(idx)); return;
            }
            case P_CALL_CONFIRM:
                if(isYes(q)){ doCall(pendB); clearPending(); } else speak("हाँ या नहीं बोलिए।");
                return;
            case P_WA_BODY:
                if(isNo(q)&&q.length()<12){ clearPending(); speak("ठीक है, रद्द कर दिया।"); return; }
                pendC=raw;
                if(pb("confirm")){ pend=P_WA_CONFIRM; speak(pendA+" को यह भेजूँ: "+raw+" ? हाँ या नहीं।"); }
                else { openWa(pendB,raw); clearPending(); }
                return;
            case P_WA_CONFIRM:
                if(isYes(q)){ openWa(pendB,pendC); clearPending(); } else speak("हाँ या नहीं बोलिए।");
                return;
            case P_REPLY_TEXT:
                if(isNo(q)&&q.length()<12){ clearPending(); speak("ठीक है, रद्द कर दिया।"); return; }
                pendA=raw;
                if(pb("ask_lang")&&pb("gemini_on")&&online()&&!ps("api_key").trim().isEmpty()){
                    pend=P_REPLY_LANG; speak("किस भाषा में भेजूँ? हिंदी, अंग्रेज़ी, मराठी, या जैसा है वैसा?");
                } else { pendB=raw; confirmReply(); }
                return;
            case P_REPLY_LANG: {
                String lang=langFromSpeech(q);
                if(lang==null||lang.equals("same")){ pendB=pendA; confirmReply(); return; }
                speak("ठीक है, "+lang+" में बना रही हूँ।");
                geminiOnce("Translate this chat message into "+lang+". Output only the translated message, nothing else.\n\n"+pendA,
                    "You are a precise translator.",(text,err) -> {
                        pendB=(text==null||text.trim().isEmpty())?pendA:text.trim(); confirmReply();
                    });
                return;
            }
            case P_REPLY_CONFIRM:
                if(isYes(q)){ sendReply(pendB); clearPending(); } else speak("हाँ या नहीं बोलिए।");
                return;
            case P_ANSWER:
                if(has(q,"नंबर","number","दोबारा","फिर से बताओ","डिजिट")){ speakFast("आख़िरी 6 अंक हैं "+lastDigits(ringNum,6)+"। उठाऊँ?"); }
                else if(has(q,"काट","cut","reject","मना")||isNo(q)){ boolean ok=tryEndCall(); clearPending(); speakFast(ok?"ठीक है, कट कर दिया।":"ठीक है, मैं कॉल नहीं उठा रही।"); }
                else if(isYes(q)||has(q,"उठा","receive","attend","जवाब दो")){ clearPending(); answerCall(); }
                else speakFast("उठाऊँ या काट दूँ? बोलिए।");
                return;
            case P_TERMUX:
                if(isYes(q)){ runTermux(pendA); clearPending(); } else speak("हाँ या नहीं बोलिए।");
                return;
            default: clearPending();
        }
    }
    private String langFromSpeech(String q){
        if(has(q,"जैसा है","वैसा ही","same","as it is","ऐसे ही")) return "same";
        if(has(q,"हिंदी","हिन्दी","hindi")) return "Hindi";
        if(has(q,"अंग्रेज","इंग्लिश","english")) return "English";
        if(has(q,"मराठी","marathi")) return "Marathi";
        if(has(q,"बंगाली","bengali")) return "Bengali";
        if(has(q,"तमिल","tamil")) return "Tamil";
        if(has(q,"तेलुगु","telugu")) return "Telugu";
        if(has(q,"गुजराती","gujarati")) return "Gujarati";
        if(has(q,"कन्नड़","kannada")) return "Kannada";
        if(has(q,"मलयालम","malayalam")) return "Malayalam";
        if(has(q,"पंजाबी","punjabi")) return "Punjabi";
        if(has(q,"उर्दू","urdu")) return "Urdu";
        if(has(q,"ओड़िया","उड़िया","odia")) return "Odia";
        return null;
    }

    // ---------- OFFLINE / LOCAL COMMANDS ----------
    private boolean handleLocal(String q,String raw){
        if(has(q,"बचाओ","sos","emergency","मुझे मदद चाहिए","तबीयत खराब","गिर गया","गिर गई","सीने में दर्द")){ sos(); return true; }
        if(has(q,"याद दिला","remind","रिमाइंडर")||(has(q,"दवा")&&has(q,"बजे"))){ reminder(q); return true; }
        if(has(q,"मेरी लोकेशन","लोकेशन बताओ","where am i","मैं कहाँ हूँ","मैं कहां हूँ")&&!has(q,"भेज","शेयर")){ tellLocation(); return true; }
        if(has(q,"लोकेशन भेज","location भेज","लोकेशन शेयर","location share")){
            pendKind="waloc"; findAndChoose(removeWords(removeWords(q,WA_STOP),"लोकेशन","location","शेयर","share","मेरी","मेरा","अपनी")); return true;
        }
        if(has(q,"स्पीड","speed","रफ़्तार","रफ्तार")&&has(q,"बताओ","कितनी","क्या")){ tellSpeed(); return true; }
        if(settingsShortcut(q)) return true;
        if(has(q,"स्क्रीनशॉट","screenshot")){ a11yGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT,"स्क्रीनशॉट ले लिया।"); return true; }
        if(has(q,"नोटिफिकेशन खोल","notification खोल","नोटिफिकेशन दिखा")){ a11yGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS,"नोटिफ़िकेशन खोल रही हूँ।"); return true; }
        if(has(q,"रीसेंट ऐप","recent apps","सारे ऐप दिखा")){ a11yGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS,"रीसेंट ऐप दिखा रही हूँ।"); return true; }
        if(has(q,"क्विक सेटिंग","quick settings")){ a11yGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS,"क्विक सेटिंग खोल रही हूँ।"); return true; }
        if(has(q,"फोन लॉक","स्क्रीन लॉक","lock screen")){ a11yGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN,"फ़ोन लॉक कर रही हूँ।"); return true; }
        if(has(q,"स्क्रीन पर क्या है","स्क्रीन पढ़ो","screen पढ़ो","क्या लिखा है")){ readScreen(); return true; }
        if(has(q,"टाइप करो","type करो")||(has(q,"लिखो")&&!has(q,"मैसेज","मेसेज","whatsapp","msg"))){
            String txt=removeWords(q,"टाइप","type","करो","लिखो","लिख","कर","दो","माया","maya");
            typeText(txt); return true;
        }
        if(has(q,"अगली रील","अगला रील","next reel","अगला शॉर्ट","next short")){ a11ySwipe(true); return true; }
        if(has(q,"पिछली रील","पिछला रील","previous reel","पिछला शॉर्ट")){ a11ySwipe(false); return true; }
        if(has(q,"लाइक करो","like करो")){ a11yClick(false,"Like","लाइक"); return true; }
        if(has(q,"सब्सक्राइब","subscribe")){ a11yClick(false,"Subscribe","सब्सक्राइब"); return true; }
        if(has(q,"भजन","कीर्तन","आरती","हनुमान चालीसा","रामायण","समाचार सुनाओ","न्यूज़ सुनाओ","खबर सुनाओ")){
            String term=removeWords(q,"चलाओ","बजाओ","सुनाओ","सुना","दो","माया","maya","खोलो","करो","एक","youtube","पर","का","की","के");
            ytSearch(term.isEmpty()?"भजन":term); speak((term.isEmpty()?"भजन":term)+" चला रही हूँ।"); return true;
        }
        if(has(q,"चुटकुला","joke")){ tellJoke(); return true; }
        if(has(q,"स्टोरेज")&&has(q,"कितना","बचा","खाली")){ storageInfo(); return true; }
        if(has(q,"का नंबर बताओ","का नंबर क्या","नंबर बताओ")&&!has(q,"कॉल")){
            pendKind="num"; findAndChoose(removeWords(removeWords(q,CALL_STOP),"बताओ","क्या","है","माया")); return true;
        }
        if(has(q,"मिस्ड कॉल","missed call","किसका कॉल आया","किसने कॉल","किसका फोन","किसने फोन","कॉल हिस्ट्री","कौन कौन से कॉल")){ readMissed(); return true; }
        if(has(q,"कॉल उठा","कॉल रिसीव","फोन उठा","फ़ोन उठा","call uth","call receive","कॉल अटेंड","call attend")){ answerCall(); return true; }
        if(has(q,"कॉल काट","फोन काट","call kat","call cut","call end","कॉल बंद","disconnect")){ endCall(); return true; }
        if(has(q,"वीडियो रोको","गाना रोको","म्यूज़िक रोको","म्यूजिक रोको","पॉज़","पाउज","pause","रोक दो","वीडियो बंद करो")){ media(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE); return true; }
        if(has(q,"अगला वीडियो","अगला गाना","next","आगे वाला")){ media(android.view.KeyEvent.KEYCODE_MEDIA_NEXT); return true; }
        if(has(q,"पिछला वीडियो","पिछला गाना","previous","पीछे वाला")){ media(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS); return true; }
        if(q.equals("चलाओ")||q.equals("वीडियो चलाओ")||q.equals("play")||q.equals("resume")||q.equals("फिर से चलाओ")){ media(android.view.KeyEvent.KEYCODE_MEDIA_PLAY); return true; }
        if(has(q,"वापस जाओ","पीछे जाओ","go back")){ a11yGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK,"वापस जा रही हूँ।"); return true; }
        if(has(q,"होम स्क्रीन","home screen","घर वापस")){ a11yGlobal(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME,"होम स्क्रीन पर जा रही हूँ।"); return true; }
        if(has(q,"नीचे स्क्रॉल","scroll down","नीचे जाओ")){ a11yScroll(true); return true; }
        if(has(q,"ऊपर स्क्रॉल","scroll up","ऊपर जाओ")){ a11yScroll(false); return true; }
        if(has(q,"इंस्टॉल बटन","install बटन","इंस्टॉल दबाओ","install दबाओ","इंस्टॉल कर दो","इंस्टॉल कीजिए")){ a11yClick(true,"Install","इंस्टॉल करें","इंस्टॉल"); return true; }
        if(has(q,"अपडेट दबाओ","update दबाओ","अपडेट कर दो")){ a11yClick(true,"Update","अपडेट करें"); return true; }
        if(has(q,"ओपन दबाओ","open दबाओ")){ a11yClick(true,"Open","खोलें"); return true; }
        if(has(q,"दबाओ","क्लिक करो","click","tap करो")){
            String term=removeWords(q,"दबाओ","क्लिक","करो","click","tap","press","बटन","button","को","पर","माया","maya","कर","दो");
            if(term.isEmpty()){ speak("क्या दबाना है? नाम बोलिए।"); return true; }
            a11yClick(false,term); return true;
        }
        if(has(q,"मैसेज पढ़","मेसेज पढ़","नोटिफिकेशन पढ़","नोटिफ़िकेशन पढ़","read message","मैसेज सुना","मैसेज बता","कोई मैसेज","नए मैसेज","किसका मैसेज","किसने मैसेज")){ readNotifs(); return true; }
        if(hw(q,"reply")||has(q,"रिप्लाई","जवाब दो","जवाब भेज")){ startReply(); return true; }
        if(has(q,"कॉल करो","कॉल लगा","फोन लगा","फोन करो","फ़ोन करो","call karo","call kar","dial","फोन मिला","कॉल मिला","को कॉल","से बात करा")){
            pendKind="call"; findAndChoose(removeWords(q,CALL_STOP)); return true;
        }
        if(has(q,"whatsapp")&&has(q,"मैसेज","message","भेज","लिख","msg","मेसेज")){
            pendKind="wa"; findAndChoose(removeWords(q,WA_STOP)); return true;
        }
        if(has(q,"termux")&&has(q,"चला","run","कमांड","command","execute")){ startTermux(q); return true; }
        if(has(q,"टाइमर","timer")){ setTimer(q); return true; }
        if(has(q,"अलार्म","alarm")){ setAlarm(q); return true; }
        if(has(q,"टॉर्च","torch","flashlight","फ्लैशलाइट","फ्लैश लाइट")){ torch(!has(q,"बंद","off","बुझा")); return true; }
        if(has(q,"वॉल्यूम","volume","आवाज़ बढ़ा","आवाज बढ़ा","आवाज़ घटा","आवाज घटा","आवाज़ कम","आवाज कम","साउंड")){ volume(q); return true; }
        if(has(q,"बैटरी","battery")){ battery(); return true; }
        if(has(q,"कितने बजे","टाइम क्या","समय क्या","what time","time kya","समय बताओ","टाइम बताओ")){ tellTime(); return true; }
        if(has(q,"आज की तारीख","तारीख क्या","आज कौन सा दिन","date kya","आज का दिन","आज की डेट","तारीख बताओ")){ tellDate(); return true; }
        if(has(q,"सेल्फी","selfie","फ्रंट कैमरा","front camera")){ takePhoto(true); return true; }
        if(has(q,"फोटो खींच","फोटो क्लिक","फोटो लो","photo click","फोटो ले","तस्वीर","फोटो","फ़ोटो")&&!has(q,"गैलरी","gallery","दिखा")){ takePhoto(false); return true; }
        if(has(q,"camera")&&has(q,"खोल","open","चालू")){ openCamera(false); speak("कैमरा खोल रही हूँ।"); return true; }
        if(has(q,"gallery")&&has(q,"खोल","open","दिखा","चालू")){ openGallery(); speak("गैलरी खोल रही हूँ।"); return true; }
        if(langSwitch(q)) return true;
        if(tryMath(q)) return true;
        if(has(q,"play store")||has(q,"डाउनलोड","download","इंस्टॉल","install")){ playStore(q); return true; }
        if(has(q,"wifi","bluetooth")&&has(q,"खोल","open","सेटिंग","चालू","बंद")){
            startSettings(q.contains("wifi")?Settings.ACTION_WIFI_SETTINGS:Settings.ACTION_BLUETOOTH_SETTINGS); return true;
        }
        if(has(q,"youtube")||has(q,"गाना","song","बजाओ","सुनाओ")){
            String term=removeWords(q,"youtube","पर","में","सर्च","search","करो","खोलो","open","चलाओ","बजाओ","play","प्ले","सुनाओ","गाना","song","का","की","के","एक","वीडियो","video","दो","कर","से");
            if(term.isEmpty()){ speak(open("com.google.android.youtube","YouTube खोल रही हूँ।")); }
            else { ytSearch(term); speak("YouTube पर "+term+" खोज रही हूँ।"); }
            return true;
        }
        if(has(q,"लोकेशन","location","रास्ता","navigate","नक्शा","maps","directions","कहाँ है","कहां है")){ maps(q); return true; }
        if(has(q,".com",".in ",".org","http","www.")){
            for(String tok:q.split(" ")) if(tok.contains(".")&&!tok.endsWith(".")){ openUrl(tok); speak("लिंक खोल रही हूँ।"); return true; }
        }
        if(has(q,"सर्च","search","खोजो","ढूंढो","ढूँढो","google पर")){
            String term=removeWords(q,"google","chrome","पर","में","सर्च","search","करो","खोजो","ढूंढो","ढूँढो","कर","दो","के","बारे","बताओ","एक","माया");
            if(!term.isEmpty()){ webSearch(term); speak(term+" सर्च कर रही हूँ।"); return true; }
        }
        if(has(q,"खोल","open","चालू करो","लॉन्च","launch","start")){ speak(openByName(q)); return true; }
        return false;
    }
    private static final String[] CALL_STOP={"कॉल","फोन","फ़ोन","call","karo","kar","dial","लगाओ","लगा","करो","कर","दो","मिलाओ","मिला","को","से","बात","करा","कराओ","नंबर","number","माया","maya","please","प्लीज","जी","एक","ज़रा","जरा","मुझे","मेरे","लिए","के","की","का","पर"};
    private static final String[] WA_STOP={"whatsapp","पर","में","को","मैसेज","मेसेज","message","msg","भेजो","भेज","दो","करो","कर","लिखो","लिख","एक","माया","maya","जी","से","के","लिए","भेजना","है","सेंड","send"};

    private void startSettings(String action){ try{ startActivity(new Intent(action)); speak("खोल रही हूँ।"); }catch(Exception e){ speak("यह स्क्रीन नहीं खुल सकी।"); } }
    private String open(String pkg,String okMsg){
        if(pb("safe")) return "सेफ़ मोड चालू है, इसलिए ऐप नहीं खोलूँगी।";
        try{
            Intent i=getPackageManager().getLaunchIntentForPackage(pkg);
            if(i!=null){ i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return okMsg; }
            return "यह ऐप इंस्टॉल नहीं है।";
        }catch(Exception e){ return "ऐप नहीं खुल सका।"; }
    }
    private String openByName(String q){
        if(pb("safe")) return "सेफ़ मोड चालू है, इसलिए ऐप नहीं खोलूँगी।";
        try{
            if(has(q,"settings")){ startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "सेटिंग्स खोल रही हूँ।"; }
            PackageManager pm=getPackageManager();
            Intent main=new Intent(Intent.ACTION_MAIN); main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> l=pm.queryIntentActivities(main,0);
            String bestPkg=null,bestLab=null; int bestLen=0;
            for(ResolveInfo r:l){
                String lab=r.loadLabel(pm).toString().toLowerCase(Locale.ROOT).trim();
                if(lab.length()<3) continue;
                if(q.contains(lab)&&lab.length()>bestLen){ bestLen=lab.length(); bestPkg=r.activityInfo.packageName; bestLab=r.loadLabel(pm).toString(); }
            }
            if(bestPkg==null){
                for(ResolveInfo r:l){
                    String lab=r.loadLabel(pm).toString().toLowerCase(Locale.ROOT).trim();
                    String first=lab.split(" ")[0];
                    if(first.length()>=4&&q.contains(first)){ bestPkg=r.activityInfo.packageName; bestLab=r.loadLabel(pm).toString(); break; }
                }
            }
            if(bestPkg==null) return "मुझे इस नाम का ऐप नहीं मिला।";
            Intent i=pm.getLaunchIntentForPackage(bestPkg);
            if(i==null) return "यह ऐप नहीं खुल सका।";
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
            return bestLab+" खोल रही हूँ।";
        }catch(Exception e){ return "ऐप नहीं खुल सका। \"दूसरे ऐप के ऊपर दिखने की अनुमति\" सेटिंग में चालू कीजिए।"; }
    }
    private void ytSearch(String term){
        Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query="+Uri.encode(term)));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try{ i.setPackage("com.google.android.youtube"); startActivity(i); }
        catch(Exception e){ try{ i.setPackage(null); startActivity(i); }catch(Exception e2){ Toast.makeText(this,"YouTube नहीं खुला",Toast.LENGTH_SHORT).show(); } }
    }
    private void webSearch(String term){
        try{ Intent i=new Intent(Intent.ACTION_WEB_SEARCH); i.putExtra(android.app.SearchManager.QUERY,term); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        catch(Exception e){ openUrl("https://www.google.com/search?q="+Uri.encode(term)); }
    }
    private void openUrl(String u){
        if(!u.startsWith("http")) u="https://"+u;
        try{ startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        catch(Exception e){ Toast.makeText(this,"लिंक नहीं खुला",Toast.LENGTH_SHORT).show(); }
    }
    private void maps(String q){
        boolean nav=has(q,"लगाओ","नेविगेट","navigate","रास्ता","चलो","जाना है","ले चलो","directions");
        String term=removeWords(q,"लोकेशन","location","रास्ता","navigate","नक्शा","maps","directions","कहाँ","कहां","है","दिखाओ","बताओ","की","का","के","में","पर","माया","मेरी","मेरा","दिखा","लगाओ","चलो","जाना","ले","नेविगेट","लगा","मुझे","को","तक");
        try{
            Intent i;
            if(nav&&!term.isEmpty()){
                i=new Intent(Intent.ACTION_VIEW,Uri.parse("google.navigation:q="+Uri.encode(term)+"&mode=d"));
                i.setPackage("com.google.android.apps.maps");
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
                speak(term+" के लिए नेविगेशन शुरू कर रही हूँ।");
            } else {
                Uri u=term.isEmpty()?Uri.parse("https://www.google.com/maps"):Uri.parse("geo:0,0?q="+Uri.encode(term));
                i=new Intent(Intent.ACTION_VIEW,u); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
                speak(term.isEmpty()?"मैप्स खोल रही हूँ।":term+" मैप्स में दिखा रही हूँ।");
            }
        }catch(Exception e){ speak("मैप्स नहीं खुल सका।"); }
    }
    private void tellSpeed(){
        try{
            if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ speak("स्पीड नापने के लिए लोकेशन की अनुमति दीजिए।"); return; }
            android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);
            String pr=lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)?android.location.LocationManager.GPS_PROVIDER:android.location.LocationManager.NETWORK_PROVIDER;
            speak("स्पीड नाप रही हूँ।");
            lm.requestSingleUpdate(pr,new android.location.LocationListener(){
                @Override public void onLocationChanged(android.location.Location l){ speak("आपकी स्पीड "+Math.round(l.getSpeed()*3.6f)+" किलोमीटर प्रति घंटा है।"); }
                @Override public void onStatusChanged(String prov,int st,Bundle ex){}
                @Override public void onProviderEnabled(String prov){}
                @Override public void onProviderDisabled(String prov){}
            },android.os.Looper.getMainLooper());
        }catch(Exception e){ speak("स्पीड नहीं नाप सकी। लोकेशन चालू कीजिए।"); }
    }
    private static final String[][] KNOWN={{"whatsapp","com.whatsapp"},{"telegram","org.telegram.messenger"},{"youtube","com.google.android.youtube"},
        {"instagram","com.instagram.android"},{"facebook","com.facebook.katana"},{"chrome","com.android.chrome"},{"phonepe","com.phonepe.app"},
        {"google pay","com.google.android.apps.nbu.paisa.user"},{"gpay","com.google.android.apps.nbu.paisa.user"},{"paytm","net.one97.paytm"},
        {"snapchat","com.snapchat.android"},{"spotify","com.spotify.music"},{"netflix","com.netflix.mediaclient"},{"zoom","us.zoom.videomeetings"},
        {"truecaller","com.truecaller"},{"amazon","in.amazon.mShop.android.shopping"},{"flipkart","com.flipkart.android"},{"mx player","com.mxtech.videoplayer.ad"},
        {"vlc","org.videolan.vlc"},{"meet","com.google.android.apps.tachyon"},{"gmail","com.google.android.gm"},{"hotstar","in.startv.hotstar"},
        {"chatgpt","com.openai.chatgpt"},{"gemini","com.google.android.apps.bard"},{"photos","com.google.android.apps.photos"}};
    private void playStore(String q){
        final String term=removeWords(q,"play store","से","पर","में","डाउनलोड","download","इंस्टॉल","install","करो","कर","दो","ऐप","app","एप","माया","maya","खोलो","search","सर्च","का","की","के","एक");
        if(term.isEmpty()){ speak(open("com.android.vending","Play Store खोल रही हूँ।")); return; }
        if(term.contains("termux")){ openUrl("https://f-droid.org/packages/com.termux/"); speak("Termux Play Store पर सही वर्ज़न में नहीं मिलता। मैं F-Droid का पेज खोल रही हूँ।"); return; }
        boolean dev=false; for(char ch:term.toCharArray()) if(ch>=0x0900&&ch<=0x097F){ dev=true; break; }
        boolean known=false; for(String[] k:KNOWN) if(term.contains(k[0])){ known=true; break; }
        if(dev&&!known&&geminiReady()){
            speak("ऐप का नाम समझ रही हूँ।");
            geminiOnce("Give only the exact English name of this Android app, nothing else: "+term,"You answer with only an app name.",(text,err) ->
                storeFlow(text==null||text.trim().isEmpty()?term:text.trim().toLowerCase(Locale.ROOT)));
        } else storeFlow(term);
    }
    private void storeFlow(String term){
        try{
            String pkg=null;
            for(String[] k:KNOWN) if(term.contains(k[0])){ pkg=k[1]; break; }
            Uri u=pkg!=null?Uri.parse("market://details?id="+pkg):Uri.parse("market://search?q="+Uri.encode(term)+"&c=apps");
            Intent i=new Intent(Intent.ACTION_VIEW,u); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            if(MayaAccessService.ready()){
                speak("Play Store में "+term+" इंस्टॉल कर रही हूँ। स्क्रीन देखते रहिए।");
                installRunning=true; installTries=0; installClicked=false; installTerm=pkg!=null?"":term;
                ui.postDelayed(() -> installLoop(),pkg!=null?4500:6500);
            } else speak("Play Store में "+term+" खोला है। अपने आप इंस्टॉल के लिए Accessibility चालू करनी होगी। अभी Install बटन आप दबाइए।");
        }catch(Exception e){ speak("Play Store नहीं खुल सका।"); }
    }
    private void installLoop(){
        if(!installRunning) return;
        if(installTries++>30||!MayaAccessService.ready()){ installRunning=false; speak("इंस्टॉल पूरा होने की पुष्टि नहीं हो सकी। स्क्रीन देखिए।"); return; }
        if(!installClicked){
            if(!installTerm.isEmpty()&&installTries==1){ MayaAccessService.clickText(false,installTerm); ui.postDelayed(() -> installLoop(),3500); return; }
            if(MayaAccessService.clickText(true,"Install","इंस्टॉल करें","इंस्टॉल")){ installClicked=true; speak("इंस्टॉल शुरू हो गया।"); }
        } else if(MayaAccessService.clickText(true,"Open","खोलें")){
            installRunning=false; speak("इंस्टॉल हो गया, ऐप खोल रही हूँ।"); return;
        }
        ui.postDelayed(() -> installLoop(),3000);
    }
    private void a11yClick(boolean exact,String... words){
        if(!MayaAccessService.ready()){ speak("पहले Accessibility चालू करनी होगी। मैं सेटिंग खोल रही हूँ।"); doAction("access"); return; }
        boolean ok=MayaAccessService.clickText(exact,words);
        speak(ok?"दबा दिया।":"मुझे स्क्रीन पर "+words[0]+" नहीं दिखा।");
    }
    private void a11yGlobal(int action,String msg){
        if(!MayaAccessService.ready()){ speak("पहले Accessibility चालू करनी होगी। मैं सेटिंग खोल रही हूँ।"); doAction("access"); return; }
        MayaAccessService.global(action); speak(msg);
    }
    private void a11yScroll(boolean forward){
        if(!MayaAccessService.ready()){ speak("पहले Accessibility चालू करनी होगी। मैं सेटिंग खोल रही हूँ।"); doAction("access"); return; }
        MayaAccessService.scroll(forward);
    }
    private void media(int key){
        try{
            long t=android.os.SystemClock.uptimeMillis();
            am.dispatchMediaKeyEvent(new android.view.KeyEvent(t,t,android.view.KeyEvent.ACTION_DOWN,key,0));
            am.dispatchMediaKeyEvent(new android.view.KeyEvent(t,t,android.view.KeyEvent.ACTION_UP,key,0));
        }catch(Exception ignored){}
    }

    // ---------- INCOMING CALLS / SYSTEM ----------
    private void registerSystemListeners(){
        try{
            IntentFilter f=new IntentFilter(android.telephony.TelephonyManager.ACTION_PHONE_STATE_CHANGED);
            if(android.os.Build.VERSION.SDK_INT>=33) registerReceiver(phoneRx,f,RECEIVER_EXPORTED); else registerReceiver(phoneRx,f);
        }catch(Exception ignored){}
        try{
            android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            netCb=new android.net.ConnectivityManager.NetworkCallback(){
                @Override public void onAvailable(android.net.Network n){ offlineUntil=0; ui.post(() -> prefetchAck()); }
            };
            cm.registerDefaultNetworkCallback(netCb);
        }catch(Exception ignored){}
    }
    private String contactNameFor(String num){
        if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED) return null;
        android.database.Cursor c=null;
        try{
            Uri u=Uri.withAppendedPath(android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI,Uri.encode(num));
            c=getContentResolver().query(u,new String[]{android.provider.ContactsContract.PhoneLookup.DISPLAY_NAME},null,null,null);
            if(c!=null&&c.moveToFirst()) return c.getString(0);
        }catch(Exception ignored){}
        finally{ if(c!=null) c.close(); }
        return null;
    }
    private String normNum(String n){
        String d=n.replaceAll("[^0-9+]","");
        if(d.startsWith("+91")) d=d.substring(3); else if(d.startsWith("0091")) d=d.substring(4);
        else if(d.startsWith("91")&&d.length()==12) d=d.substring(2);
        if(d.startsWith("0")&&d.length()>10) d=d.substring(1);
        return d;
    }
    private String classify(String num){
        if(num==null||num.trim().isEmpty()) return "hidden";
        String raw=num.trim(); String d=normNum(num);
        if(raw.startsWith("+")&&!raw.startsWith("+91")) return "foreign";
        if(d.startsWith("1")||d.length()<=6) return "company";
        return "personal";
    }
    private boolean tryEndCall(){
        try{
            if(android.os.Build.VERSION.SDK_INT<28||checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS)!=PackageManager.PERMISSION_GRANTED) return false;
            return ((android.telecom.TelecomManager)getSystemService(TELECOM_SERVICE)).endCall();
        }catch(Exception e){ return false; }
    }
    private void onRinging(String num){
        long now=System.currentTimeMillis();
        boolean canSeeNumber=checkSelfPermission(Manifest.permission.READ_CALL_LOG)==PackageManager.PERMISSION_GRANTED;
        if((num==null||num.isEmpty())&&canSeeNumber) return;
        if(pend==P_ANSWER&&now-lastRing<4000) return;
        lastRing=now;
        if(!pb("call_announce")) return;
        String nm=(num!=null&&!num.isEmpty())?contactNameFor(num):null;
        String type=nm!=null?"contact":classify(num);
        ringNum=num==null?"":num;
        if(!micOn&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED){ micOn=true; updateFg(); }
        String d6=lastDigits(ringNum,6);
        if(type.equals("company")&&pb("cut_company")&&tryEndCall()){
            speakFast("बॉस, ये कंपनी का कॉल था, मैंने कट कर दिया। आख़िरी अंक थे "+d6+"।"); return;
        }
        String msg;
        if(type.equals("contact")) msg=nm+" का कॉल आ रहा है। उठाऊँ?";
        else if(type.equals("company")) msg="बॉस, ये कंपनी का कॉल लग रहा है। आख़िरी 6 अंक हैं "+d6+"। उठाऊँ या काट दूँ?";
        else if(type.equals("foreign")) msg="बॉस, विदेशी नंबर से कॉल आ रहा है। आख़िरी 6 अंक हैं "+d6+"। सावधान रहिए, उठाऊँ?";
        else if(type.equals("hidden")) msg="बॉस, किसी का कॉल आ रहा है, नंबर दिख नहीं रहा। उठाऊँ?";
        else msg="बॉस, किसी का कॉल आ रहा है, ये कंपनी का नहीं लगता। नंबर के आख़िरी 6 अंक हैं "+d6+"। उठाऊँ?";
        if(pb("auto_answer")&&!type.equals("company")){
            speakFast(msg.replace("उठाऊँ?","मैं उठा रही हूँ।"));
            ui.postDelayed(() -> answerCall(),2200);
            return;
        }
        clearPending(); pend=P_ANSWER;
        speakFast(msg);
    }
    private void readMissed(){
        if(checkSelfPermission(Manifest.permission.READ_CALL_LOG)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.READ_CALL_LOG,Manifest.permission.READ_CONTACTS},REQ_PHONE);
            speak("कॉल की जानकारी की अनुमति दीजिए, फिर दोबारा पूछिए।"); return;
        }
        android.database.Cursor c=null;
        try{
            c=getContentResolver().query(android.provider.CallLog.Calls.CONTENT_URI,
                new String[]{android.provider.CallLog.Calls.NUMBER,android.provider.CallLog.Calls.CACHED_NAME},
                android.provider.CallLog.Calls.TYPE+"="+android.provider.CallLog.Calls.MISSED_TYPE,null,android.provider.CallLog.Calls.DATE+" DESC");
            StringBuilder sb=new StringBuilder(); int n=0;
            while(c!=null&&c.moveToNext()&&n<3){
                String num=c.getString(0), name=c.getString(1);
                if(name==null||name.isEmpty()) name=num==null?null:contactNameFor(num);
                sb.append(name!=null?name:"अनजान नंबर, आख़िरी अंक "+lastDigits(num==null?"":num,4)).append("। ");
                n++;
            }
            if(n==0) speak("कोई मिस्ड कॉल नहीं है।");
            else speak("आपके हाल के मिस्ड कॉल: "+sb);
        }catch(Exception e){ speak("कॉल की जानकारी नहीं मिल सकी।"); }
        finally{ if(c!=null) c.close(); }
    }
    // ---------- SETUP WIZARD ----------
    private static final String[] ALL_PERMS={"android.permission.RECORD_AUDIO","android.permission.CAMERA","android.permission.READ_CONTACTS",
        "android.permission.CALL_PHONE","android.permission.ANSWER_PHONE_CALLS","android.permission.READ_PHONE_STATE","android.permission.READ_CALL_LOG",
        "android.permission.ACCESS_FINE_LOCATION","android.permission.ACCESS_COARSE_LOCATION","android.permission.POST_NOTIFICATIONS","com.termux.permission.RUN_COMMAND"};
    private void startWizard(){
        wizard=0;
        speak("नमस्ते "+callName()+", मैं माया हूँ। अब मैं ज़रूरी अनुमतियाँ माँगूँगी। हर सवाल पर अनुमति दे दीजिए।");
        ui.postDelayed(() -> requestPermissions(ALL_PERMS,REQ_ALL),3500);
    }
    private boolean notifListenerOn(){
        String l=Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners");
        return l!=null&&l.contains(getPackageName());
    }
    private boolean locationOn(){
        try{
            android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);
            return lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)||lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER);
        }catch(Exception e){ return true; }
    }
    private void nextWizard(){
        if(wizard<1) return;
        if(wizard==1){ wizard=2; if(!Settings.canDrawOverlays(this)){ speak("अब \"दूसरे ऐप के ऊपर दिखने\" में माया को चालू कीजिए।"); doAction("overlay"); return; } }
        if(wizard==2){ wizard=3; if(!notifListenerOn()){ speak("अब मैसेज पढ़ने के लिए सूची में माया को चालू कीजिए।"); doAction("notif_access"); return; } }
        if(wizard==3){ wizard=4; if(!MayaAccessService.ready()){ speak("अब स्क्रीन पर बटन दबाने के लिए, सूची में माया को चालू कीजिए।"); doAction("access"); return; } }
        if(wizard==4){ wizard=5; if(!((android.os.PowerManager)getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName())){ speak("अब बैटरी में माया को बिना पाबंदी वाला कीजिए।"); doAction("battery"); return; } }
        if(wizard==5){ wizard=6; if(!locationOn()){ speak("अब लोकेशन चालू कीजिए।"); try{ startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); }catch(Exception ignored){} return; } }
        if(wizard==6){ wizard=7; if(ps("api_key").trim().isEmpty()){ speak("अब Gemini की Key चाहिए, ताकि मेरी आवाज़ और जवाब बढ़िया हों। मैं Key का पेज खोल रही हूँ। वहाँ Create API key दबाकर Key कॉपी कीजिए और फिर वापस आइए।"); ui.postDelayed(() -> openUrl("https://aistudio.google.com/apikey"),6500); return; } }
        if(wizard==7){ wizard=8; if(ps("api_key").trim().isEmpty()){ if(!pasteKey(false)){ speak("Key नहीं मिली। सेटिंग में Key पेस्ट कीजिए।"); showSettingsPage(); return; } } }
        wizard=-1; prefs.edit().putBoolean("wizard_done",true).apply();
        speak("सेटअप पूरा हुआ। अब मैं पूरी तरह तैयार हूँ।");
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED&&!micOn){ micOn=true; updateFg(); }
    }

    // ---------- LOCATION / SOS / REMINDERS / EXTRAS ----------
    private android.location.Location lastLoc(){
        try{
            if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED) return null;
            android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);
            android.location.Location best=null;
            for(String pr:lm.getProviders(true)){
                android.location.Location l=lm.getLastKnownLocation(pr);
                if(l!=null&&(best==null||l.getTime()>best.getTime())) best=l;
            }
            return best;
        }catch(Exception e){ return null; }
    }
    private void tellLocation(){
        final android.location.Location l=lastLoc();
        if(l==null){
            speak("लोकेशन नहीं मिली। लोकेशन चालू कीजिए।");
            try{ startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }catch(Exception ignored){}
            return;
        }
        speak("आपकी लोकेशन ढूँढ रही हूँ।");
        new Thread(() -> {
            String addr=null;
            try{
                List<android.location.Address> a=new android.location.Geocoder(this,new Locale("hi","IN")).getFromLocation(l.getLatitude(),l.getLongitude(),1);
                if(a!=null&&!a.isEmpty()) addr=a.get(0).getAddressLine(0);
            }catch(Exception ignored){}
            final String ad=addr;
            ui.post(() -> {
                if(ad!=null) speak("आप यहाँ हैं: "+ad);
                else {
                    speak("पता नहीं मिला, पर मैं मैप्स में आपकी लोकेशन दिखा रही हूँ।");
                    try{ startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("geo:"+l.getLatitude()+","+l.getLongitude()+"?q="+l.getLatitude()+","+l.getLongitude())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }catch(Exception ignored){}
                }
            });
        }).start();
    }
    private void sos(){
        String n=ps("sos_number").trim();
        final String num=n.isEmpty()?"112":n;
        speakFast(n.isEmpty()?"आपातकालीन नंबर 112 पर कॉल लगा रही हूँ।":"आपातकालीन नंबर पर कॉल लगा रही हूँ।");
        ui.postDelayed(() -> doCall(num),1200);
    }
    private void reminder(String q){
        int n=firstInt(q);
        String msg=removeWords(q,"याद","दिलाना","दिला","दिलाओ","remind","रिमाइंडर","मुझे","मिनट","घंटे","घंटा","बाद","बजे","में","को","कि","माया","maya","रोज़","रोज","सुबह","शाम","रात","दोपहर","कर","दो","करो","सेकंड","second").replaceAll("\\d+","").trim();
        if(msg.isEmpty()) msg="रिमाइंडर";
        try{
            if(has(q,"बजे")&&n>=0&&n<=24){
                int h=n; if(h<12&&has(q,"शाम","रात","दोपहर","pm")) h+=12;
                Intent i=new Intent(AlarmClock.ACTION_SET_ALARM);
                i.putExtra(AlarmClock.EXTRA_HOUR,h); i.putExtra(AlarmClock.EXTRA_MINUTES,0); i.putExtra(AlarmClock.EXTRA_MESSAGE,msg); i.putExtra(AlarmClock.EXTRA_SKIP_UI,true);
                if(has(q,"रोज़","रोज","daily")){ ArrayList<Integer> days=new ArrayList<>(); for(int k=1;k<=7;k++) days.add(k); i.putExtra(AlarmClock.EXTRA_DAYS,days); }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
                speak("ठीक है, "+h+" बजे "+msg+" याद दिलाऊँगी।");
            } else if(n>0&&n<=86400){
                int mult=has(q,"सेकंड","second")?1:has(q,"घंटा","घंटे","hour")?3600:60;
                Intent i=new Intent(AlarmClock.ACTION_SET_TIMER);
                i.putExtra(AlarmClock.EXTRA_LENGTH,n*mult); i.putExtra(AlarmClock.EXTRA_MESSAGE,msg); i.putExtra(AlarmClock.EXTRA_SKIP_UI,true);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
                speak("ठीक है, "+n+(mult==1?" सेकंड":mult==3600?" घंटे":" मिनट")+" बाद "+msg+" याद दिलाऊँगी।");
            } else speak("कब याद दिलाऊँ? जैसे: दस मिनट बाद दवा याद दिलाना।");
        }catch(Exception e){ speak("रिमाइंडर नहीं लग सका।"); }
    }
    private boolean settingsShortcut(String q){
        if(!has(q,"सेटिंग","settings","खोल","चालू","open")) return false;
        String act=null;
        if(has(q,"डिस्प्ले","ब्राइटनेस","brightness")) act=Settings.ACTION_DISPLAY_SETTINGS;
        else if(has(q,"साउंड","sound")) act=Settings.ACTION_SOUND_SETTINGS;
        else if(has(q,"बैटरी","battery")) act=Settings.ACTION_BATTERY_SAVER_SETTINGS;
        else if(has(q,"लोकेशन","location","gps")) act=Settings.ACTION_LOCATION_SOURCE_SETTINGS;
        else if(has(q,"एयरप्लेन","हवाई जहाज","airplane")) act=Settings.ACTION_AIRPLANE_MODE_SETTINGS;
        else if(has(q,"मोबाइल डेटा","mobile data")) act=Settings.ACTION_DATA_ROAMING_SETTINGS;
        else if(has(q,"स्टोरेज")) act=Settings.ACTION_INTERNAL_STORAGE_SETTINGS;
        else if(has(q,"भाषा")) act=Settings.ACTION_LOCALE_SETTINGS;
        else if(has(q,"ऐप")&&has(q,"सेटिंग")) act=Settings.ACTION_APPLICATION_SETTINGS;
        else if(has(q,"हॉटस्पॉट","hotspot")) act=Settings.ACTION_WIRELESS_SETTINGS;
        if(act==null) return false;
        startSettings(act); return true;
    }
    private void readScreen(){
        if(!MayaAccessService.ready()){ speak("पहले Accessibility चालू करनी होगी। मैं सेटिंग खोल रही हूँ।"); doAction("access"); return; }
        String t=MayaAccessService.screenText();
        speak(t.isEmpty()?"स्क्रीन पर पढ़ने लायक कुछ नहीं दिखा।":t);
    }
    private void typeText(String t){
        if(!MayaAccessService.ready()){ speak("पहले Accessibility चालू करनी होगी। मैं सेटिंग खोल रही हूँ।"); doAction("access"); return; }
        if(t.isEmpty()){ speak("क्या टाइप करूँ?"); return; }
        speak(MayaAccessService.type(t)?"टाइप कर दिया।":"टाइप करने के लिए पहले लिखने की जगह पर टैप कीजिए।");
    }
    private void a11ySwipe(boolean up){
        if(!MayaAccessService.ready()){ speak("पहले Accessibility चालू करनी होगी। मैं सेटिंग खोल रही हूँ।"); doAction("access"); return; }
        MayaAccessService.swipe(up);
    }
    private void tellJoke(){
        String[] j={"एक आदमी डॉक्टर के पास गया और बोला, मुझे भूलने की बीमारी है। डॉक्टर ने पूछा, कब से? आदमी बोला, कब से क्या?",
            "टीचर ने पूछा, बताओ पानी कब ख़तरनाक होता है? बच्चा बोला, जब सर के ऊपर से गुज़र जाए।",
            "पत्नी ने पति से कहा, आज खाना बाहर खाएँगे। पति बोला, ठीक है, मैं आपको बाहर बैठा देता हूँ, खाना मैं अंदर ला दूँगा।",
            "मरीज़ ने कहा, डॉक्टर साहब, मुझे रात को नींद नहीं आती। डॉक्टर बोला, तो दिन में सो लिया कीजिए।"};
        speak(j[new Random().nextInt(j.length)]);
    }
    private void storageInfo(){
        try{
            android.os.StatFs sf=new android.os.StatFs(android.os.Environment.getDataDirectory().getPath());
            long free=sf.getAvailableBytes()/(1024L*1024L*1024L), total=sf.getTotalBytes()/(1024L*1024L*1024L);
            speak("फ़ोन में "+total+" जीबी में से "+free+" जीबी खाली है।");
        }catch(Exception e){ speak("स्टोरेज की जानकारी नहीं मिली।"); }
    }
    private boolean pasteKey(boolean verbose){
        try{
            android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            android.content.ClipData cd=cm.getPrimaryClip();
            String t=(cd!=null&&cd.getItemCount()>0&&cd.getItemAt(0).getText()!=null)?cd.getItemAt(0).getText().toString().trim():"";
            if(t.startsWith("AIza")&&t.length()>=30&&!t.contains(" ")){
                prefs.edit().putString("s_api_key",t).apply();
                prefetchAck();
                if(verbose){ Toast.makeText(this,"Key सेव हो गई",Toast.LENGTH_SHORT).show(); showSettingsPage(); }
                else speak("Gemini Key मिल गई और सेव हो गई।");
                return true;
            }
            if(verbose) Toast.makeText(this,"क्लिपबोर्ड में Key नहीं मिली। पहले Key कॉपी कीजिए (AIza... से शुरू)",Toast.LENGTH_LONG).show();
        }catch(Exception e){ if(verbose) Toast.makeText(this,"क्लिपबोर्ड नहीं पढ़ सकी",Toast.LENGTH_SHORT).show(); }
        return false;
    }
    private void testVoice(){
        if(ps("api_key").trim().isEmpty()){ Toast.makeText(this,"पहले Gemini Key डालिए",Toast.LENGTH_LONG).show(); return; }
        ttsFailUntil=0; voiceTest=true;
        Toast.makeText(this,"Gemini आवाज़ जाँच रही हूँ...",Toast.LENGTH_SHORT).show();
        speak("नमस्ते बॉस, मैं माया हूँ। आपसे बात करके बहुत अच्छा लगा।");
    }
    private void chooseVoice(){
        if(!ttsReady||tts==null){ Toast.makeText(this,"आवाज़ अभी तैयार नहीं है",Toast.LENGTH_SHORT).show(); return; }
        final ArrayList<android.speech.tts.Voice> vs=new ArrayList<>();
        try{
            Set<android.speech.tts.Voice> all=tts.getVoices();
            if(all!=null) for(android.speech.tts.Voice v:all){
                Locale l=v.getLocale();
                if(l!=null&&(l.getLanguage().equals("hi")||(l.getLanguage().equals("en")&&"IN".equals(l.getCountry())))) vs.add(v);
            }
        }catch(Exception ignored){}
        if(vs.isEmpty()){ Toast.makeText(this,"कोई आवाज़ नहीं मिली। फ़ोन की Text-to-speech सेटिंग में Hindi आवाज़ डाउनलोड कीजिए।",Toast.LENGTH_LONG).show(); return; }
        Collections.sort(vs,(a,b)->b.getQuality()-a.getQuality());
        String[] names=new String[vs.size()];
        for(int i=0;i<names.length;i++){
            android.speech.tts.Voice v=vs.get(i);
            names[i]=v.getName()+" ("+v.getLocale().toLanguageTag()+(v.isNetworkConnectionRequired()?", ऑनलाइन":", ऑफ़लाइन")+")";
        }
        new AlertDialog.Builder(this).setTitle("आवाज़ चुनिए (चुनते ही सुनाई देगी)").setItems(names,(d,w)->{
            android.speech.tts.Voice v=vs.get(w);
            try{ tts.setVoice(v); }catch(Exception ignored){}
            prefs.edit().putString("s_voice_name",v.getName()).apply();
            speakFast("नमस्ते बॉस, मैं माया हूँ।");
        }).show();
    }
    private void pickBestVoice(String tag){
        try{
            Locale want=Locale.forLanguageTag(tag);
            android.speech.tts.Voice best=null;
            Set<android.speech.tts.Voice> all=tts.getVoices();
            if(all==null) return;
            String saved=prefs.getString("s_voice_name","");
            if(!saved.isEmpty()) for(android.speech.tts.Voice v:all) if(v.getName().equals(saved)){ tts.setVoice(v); return; }
            for(android.speech.tts.Voice v:all){
                Locale vl=v.getLocale();
                if(vl==null||!vl.getLanguage().equals(want.getLanguage())||v.isNetworkConnectionRequired()) continue;
                if(best==null||v.getQuality()>best.getQuality()) best=v;
            }
            if(best!=null) tts.setVoice(best);
        }catch(Exception ignored){}
    }
    private boolean langSwitch(String q){
        if(!has(q,"में बात","में बोल","भाषा बदल","भाषा","language","speak in","बात करो")) return false;
        String lang=langFromSpeech(q);
        if(lang==null||lang.equals("same")) return false;
        prefs.edit().putString("s_reply_lang",lang).putString("s_listen_lang",langTag(lang).equals("hi-IN")&&lang.equals("Hinglish")?"hi-IN":langTag(lang)).apply();
        applySettings();
        speak("ठीक है, अब मैं "+lang+" में बात करूँगी।");
        return true;
    }
    private boolean tryMath(String q){
        Matcher m=Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(\\+|-|x|\\*|/|plus|minus|into|times|divided by|जोड़|प्लस|घटा|माइनस|गुणा|गुना|भाग|बटा|इन्टू|इंटू)\\s*(\\d+(?:\\.\\d+)?)").matcher(q);
        if(!m.find()) return false;
        double a=Double.parseDouble(m.group(1)), b=Double.parseDouble(m.group(3)); String op=m.group(2); double r; String w;
        if(op.equals("+")||op.equals("plus")||op.equals("जोड़")||op.equals("प्लस")){ r=a+b; w="जोड़"; }
        else if(op.equals("-")||op.equals("minus")||op.equals("घटा")||op.equals("माइनस")){ r=a-b; w="घटा"; }
        else if(op.equals("x")||op.equals("*")||op.equals("into")||op.equals("times")||op.equals("गुणा")||op.equals("गुना")||op.equals("इन्टू")||op.equals("इंटू")){ r=a*b; w="गुणा"; }
        else { if(b==0){ speak("शून्य से भाग नहीं हो सकता।"); return true; } r=a/b; w="भाग"; }
        speak(fmt(a)+" "+w+" "+fmt(b)+" बराबर "+fmt(r));
        return true;
    }
    private String fmt(double d){ return d==Math.rint(d)?String.valueOf((long)d):String.format(Locale.ROOT,"%.2f",d); }
    private void tellTime(){
        Calendar c=Calendar.getInstance(); int h=c.get(Calendar.HOUR); if(h==0) h=12; int m=c.get(Calendar.MINUTE);
        speak("अभी "+h+" बजकर "+m+" मिनट हुए हैं।");
    }
    private void tellDate(){
        speak("आज "+new java.text.SimpleDateFormat("d MMMM yyyy, EEEE",new Locale("hi","IN")).format(new Date())+" है।");
    }
    private void battery(){
        Intent b=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if(b==null){ speak("बैटरी की जानकारी नहीं मिली।"); return; }
        int lv=b.getIntExtra("level",-1), sc=b.getIntExtra("scale",100), st=b.getIntExtra("status",-1);
        boolean chg=st==2||st==5;
        speak("बैटरी "+(lv*100/Math.max(1,sc))+" प्रतिशत है"+(chg?", और चार्ज हो रही है।":"।"));
    }
    private void torch(boolean on){
        try{
            android.hardware.camera2.CameraManager cm=(android.hardware.camera2.CameraManager)getSystemService(CAMERA_SERVICE);
            for(String id:cm.getCameraIdList()){
                Boolean f=cm.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if(f!=null&&f){ cm.setTorchMode(id,on); speak(on?"टॉर्च चालू कर दी।":"टॉर्च बंद कर दी।"); return; }
            }
            speak("इस फ़ोन में टॉर्च नहीं मिली।");
        }catch(Exception e){ speak("टॉर्च नहीं चल सकी।"); }
    }
    private void volume(String q){
        try{
            int s=android.media.AudioManager.STREAM_MUSIC;
            if(has(q,"म्यूट","mute")){ am.adjustStreamVolume(s,android.media.AudioManager.ADJUST_MUTE,android.media.AudioManager.FLAG_SHOW_UI); speak("आवाज़ म्यूट कर दी।"); return; }
            boolean up=has(q,"बढ़ा","ज़्यादा","ज्यादा","up","तेज","फुल","full");
            boolean down=has(q,"घटा","कम","down","धीमा","धीरे");
            if(up||down){
                for(int i=0;i<3;i++) am.adjustStreamVolume(s,up?android.media.AudioManager.ADJUST_RAISE:android.media.AudioManager.ADJUST_LOWER,i==2?android.media.AudioManager.FLAG_SHOW_UI:0);
                speak(up?"आवाज़ बढ़ा दी।":"आवाज़ घटा दी।");
            } else speak("आवाज़ बढ़ानी है या घटानी?");
        }catch(Exception e){ speak("आवाज़ नहीं बदल सकी।"); }
    }
    private int firstInt(String q){ Matcher m=Pattern.compile("\\d+").matcher(q); return m.find()?Integer.parseInt(m.group()):-1; }
    private void setTimer(String q){
        int n=firstInt(q);
        if(n<=0||n>86400){ speak("कितने मिनट का टाइमर लगाऊँ?"); return; }
        int mult=has(q,"सेकंड","second")?1:has(q,"घंटा","घंटे","hour")?3600:60;
        try{
            Intent i=new Intent(AlarmClock.ACTION_SET_TIMER);
            i.putExtra(AlarmClock.EXTRA_LENGTH,n*mult); i.putExtra(AlarmClock.EXTRA_SKIP_UI,true); i.putExtra(AlarmClock.EXTRA_MESSAGE,"Maya");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
            speak(n+(mult==1?" सेकंड":mult==3600?" घंटे":" मिनट")+" का टाइमर लगा दिया।");
        }catch(Exception e){ speak("टाइमर नहीं लग सका।"); }
    }
    private void setAlarm(String q){
        Matcher m=Pattern.compile("\\d+").matcher(q);
        int h=-1,mi=0;
        if(m.find()) h=Integer.parseInt(m.group());
        if(m.find()){ int x=Integer.parseInt(m.group()); if(x<60) mi=x; }
        if(h<0||h>23){ speak("कितने बजे का अलार्म लगाऊँ?"); return; }
        if(h<12&&has(q,"शाम","रात","दोपहर","pm")) h+=12;
        try{
            Intent i=new Intent(AlarmClock.ACTION_SET_ALARM);
            i.putExtra(AlarmClock.EXTRA_HOUR,h); i.putExtra(AlarmClock.EXTRA_MINUTES,mi); i.putExtra(AlarmClock.EXTRA_SKIP_UI,true); i.putExtra(AlarmClock.EXTRA_MESSAGE,"Maya");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i);
            speak(h+" बजकर "+mi+" मिनट का अलार्म लगा दिया।");
        }catch(Exception e){ speak("अलार्म नहीं लग सका।"); }
    }
    private void openCamera(boolean front){
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
            pendingFront=front; requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA); return;
        }
        try{
            Intent i=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            if(front){ i.putExtra("android.intent.extras.CAMERA_FACING",1); i.putExtra("android.intent.extras.LENS_FACING_FRONT",1); i.putExtra("android.intent.extra.USE_FRONT_CAMERA",true); }
            startActivity(i);
        }catch(Exception e){ Toast.makeText(this,"कैमरा नहीं खुला",Toast.LENGTH_SHORT).show(); }
    }
    private void takePhoto(final boolean front){
        if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
            pendingFront=front; requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA); return;
        }
        if(shot!=null) return;
        shot=new CameraShot(this,front,new CameraShot.Cb(){
            @Override public void ready(){
                speakFast("तीन, दो, एक, मुस्कुराइए!");
                ui.postDelayed(() -> { if(shot!=null) shot.capture(); },4200);
            }
            @Override public void done(Uri uri,String path){
                shot=null; Toast.makeText(MainActivity.this,"फोटो सेव हुई: "+path,Toast.LENGTH_LONG).show();
                speakFast("फोटो खिंच गई है।");
            }
            @Override public void fail(String why){
                shot=null; Toast.makeText(MainActivity.this,why,Toast.LENGTH_SHORT).show();
                openCamera(front);
            }
        });
        shot.start();
    }
    private void openGallery(){
        try{ Intent i=Intent.makeMainSelectorActivity(Intent.ACTION_MAIN,Intent.CATEGORY_APP_GALLERY); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); }
        catch(Exception e){ try{ Intent v=new Intent(Intent.ACTION_VIEW); v.setType("image/*"); startActivity(v); }catch(Exception e2){ Toast.makeText(this,"गैलरी नहीं खुली",Toast.LENGTH_SHORT).show(); } }
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
        boolean ok=g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED;
        if(r==REQ_AUDIO){ if(ok){ micOn=true; updateFg(); startListening(); } else Toast.makeText(this,"माइक की अनुमति चाहिए",Toast.LENGTH_SHORT).show(); }
        else if(r==REQ_CAMERA){ if(ok) takePhoto(pendingFront); else Toast.makeText(this,"कैमरा की अनुमति चाहिए",Toast.LENGTH_SHORT).show(); }
        else if(r==REQ_ALL){ wizard=1; ui.postDelayed(() -> nextWizard(),500); }
        else if(r==REQ_PHONE){ Toast.makeText(this,"अनुमति का जवाब मिल गया। अब दोबारा बोलिए।",Toast.LENGTH_SHORT).show(); }
    }

    // ---------- CONTACTS / CALLS ----------
    private String devMap(char c){
        switch(c){
            case 'क': case 'ख': return "k"; case 'ग': case 'घ': return "g"; case 'च': case 'छ': return "c";
            case 'ज': case 'झ': return "j"; case 'ट': case 'ठ': case 'त': case 'थ': return "t";
            case 'ड': case 'ढ': case 'द': case 'ध': return "d"; case 'ण': case 'न': case 'ं': case 'ँ': case 'ङ': case 'ञ': return "n";
            case 'प': return "p"; case 'फ': return "f"; case 'ब': case 'भ': return "b"; case 'म': return "m";
            case 'र': return "r"; case 'ल': return "l"; case 'व': return "v"; case 'श': case 'ष': case 'स': return "s";
            default: return "";
        }
    }
    private String skeleton(String s){
        s=s.toLowerCase(Locale.ROOT).replace("ph","f").replace("sh","s").replace("ch","c").replace("kh","k").replace("gh","g")
            .replace("th","t").replace("dh","d").replace("bh","b").replace("ck","k").replace("w","v").replace("z","j").replace("q","k").replace("x","ks");
        StringBuilder sb=new StringBuilder();
        for(char c:s.toCharArray()){
            String m;
            if(c>=0x0900&&c<=0x097F) m=devMap(c);
            else if(c>='a'&&c<='z'&&"aeiouhy".indexOf(c)<0) m=String.valueOf(c);
            else m="";
            if(m.isEmpty()) continue;
            if(sb.length()>0&&sb.charAt(sb.length()-1)==m.charAt(0)) continue;
            sb.append(m);
        }
        return sb.toString().replace('m','n').replaceAll("n+","n");
    }
    private ArrayList<String[]> findContacts(String nameQuery){
        ArrayList<String[]> out=new ArrayList<>();
        String sk=skeleton(nameQuery);
        if(sk.length()<2) return out;
        android.database.Cursor cur=null;
        try{
            cur=getContentResolver().query(android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null);
            HashSet<String> seen=new HashSet<>();
            while(cur!=null&&cur.moveToNext()){
                String n=cur.getString(0), num=cur.getString(1);
                if(n==null||num==null) continue;
                String ns=skeleton(n);
                if(ns.contains(sk)||(ns.length()>=3&&sk.contains(ns))){
                    String key=num.replaceAll("[^0-9+]","");
                    if(seen.add(key)){ out.add(new String[]{n,num}); if(out.size()>=5) break; }
                }
            }
        }catch(Exception ignored){}
        finally{ if(cur!=null) cur.close(); }
        return out;
    }
    private String spokenDigits(String num){
        StringBuilder sb=new StringBuilder();
        for(char c:num.toCharArray()) if(c>='0'&&c<='9') sb.append(c).append(' ');
        return sb.toString().trim();
    }
    private String lastDigits(String num,int n){
        String d=num.replaceAll("[^0-9]",""); if(d.length()>n) d=d.substring(d.length()-n);
        return spokenDigits(d);
    }
    private void findAndChoose(String name){
        if(name.trim().isEmpty()){ pend=P_NAME; speak("किसे? नाम बोलिए।"); return; }
        if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS,Manifest.permission.CALL_PHONE,Manifest.permission.ANSWER_PHONE_CALLS,Manifest.permission.READ_PHONE_STATE,Manifest.permission.READ_CALL_LOG},REQ_PHONE);
            speak("पहले कॉन्टैक्ट की अनुमति दीजिए, फिर दोबारा बोलिए।"); return;
        }
        ArrayList<String[]> r=findContacts(name);
        if(r.isEmpty()){ clearPending(); Toast.makeText(this,"खोजा: "+name,Toast.LENGTH_LONG).show(); speak("मुझे "+name+" नाम का कोई कॉन्टैक्ट नहीं मिला। नाम दोबारा बोलकर देखिए।"); return; }
        pendList.clear(); pendList.addAll(r);
        if(r.size()==1){ afterPick(r.get(0)); return; }
        pend=P_CHOOSE;
        StringBuilder sb=new StringBuilder("मुझे "+r.size()+" नाम मिले। ");
        for(int i=0;i<r.size();i++) sb.append(i+1).append(": ").append(r.get(i)[0]).append(", अंतिम अंक ").append(lastDigits(r.get(i)[1],3)).append("। ");
        sb.append("कौन सा? नंबर बोलिए।");
        speak(sb.toString());
    }
    private void afterPick(String[] c){
        pendA=c[0]; pendB=c[1];
        if(pendKind.equals("num")){ clearPending(); speak(c[0]+" का नंबर "+spokenDigits(c[1])+" है।"); return; }
        if(pendKind.equals("waloc")){
            android.location.Location loc=lastLoc();
            if(loc==null){ clearPending(); speak("लोकेशन नहीं मिली। लोकेशन चालू कीजिए।"); return; }
            openWa(c[1],"मेरी लोकेशन: https://maps.google.com/?q="+loc.getLatitude()+","+loc.getLongitude());
            clearPending(); return;
        }
        if(pendKind.equals("wa")){ pend=P_WA_BODY; speak(c[0]+" को क्या मैसेज भेजना है?"); return; }
        if(!pb("confirm")){ doCall(c[1]); clearPending(); return; }
        pend=P_CALL_CONFIRM;
        speak(c[0]+" का नंबर "+spokenDigits(c[1])+" है। कॉल करूँ?");
    }
    private void doCall(String number){
        try{
            Uri u=Uri.parse("tel:"+Uri.encode(number));
            if(checkSelfPermission(Manifest.permission.CALL_PHONE)==PackageManager.PERMISSION_GRANTED) startActivity(new Intent(Intent.ACTION_CALL,u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            else startActivity(new Intent(Intent.ACTION_DIAL,u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }catch(Exception e){ Toast.makeText(this,"कॉल नहीं लग सकी",Toast.LENGTH_SHORT).show(); }
    }
    private void openWa(String number,String text){
        String d=number.replaceAll("[^0-9]","");
        if(!number.trim().startsWith("+")){ if(d.startsWith("0")) d=d.substring(1); if(d.length()==10) d=ps("cc").trim()+d; }
        try{
            Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+d+"?text="+Uri.encode(text))); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try{ i.setPackage("com.whatsapp"); startActivity(i); }catch(Exception e){ i.setPackage(null); startActivity(i); }
            if(MayaAccessService.ready()){ speak("मैसेज भेज रही हूँ।"); waTries=0; ui.postDelayed(() -> waSendLoop(),3000); }
            else speak("WhatsApp में मैसेज तैयार है। Send आप दबाइए। अपने आप भेजने के लिए Accessibility चालू करें।");
        }catch(Exception e){ speak("WhatsApp नहीं खुला।"); }
    }
    private void waSendLoop(){
        if(waTries++>6){ speak("Send बटन नहीं मिला। आप Send दबा दीजिए।"); return; }
        if(MayaAccessService.clickText(true,"Send","भेजें","भेजो")){ speak("मैसेज भेज दिया।"); return; }
        ui.postDelayed(() -> waSendLoop(),1200);
    }
    private void answerCall(){
        try{
            if(checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS)!=PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.ANSWER_PHONE_CALLS},REQ_PHONE); speak("कॉल उठाने की अनुमति दीजिए, फिर दोबारा बोलिए।"); return;
            }
            android.telecom.TelecomManager tm=(android.telecom.TelecomManager)getSystemService(TELECOM_SERVICE);
            tm.acceptRingingCall();
        }catch(Exception e){ speak("कॉल नहीं उठा सकी।"); }
    }
    private void endCall(){
        try{
            if(checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS)!=PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.ANSWER_PHONE_CALLS},REQ_PHONE); speak("कॉल काटने की अनुमति दीजिए, फिर दोबारा बोलिए।"); return;
            }
            android.telecom.TelecomManager tm=(android.telecom.TelecomManager)getSystemService(TELECOM_SERVICE);
            if(android.os.Build.VERSION.SDK_INT>=28) tm.endCall(); else speak("इस Android में कॉल काटना संभव नहीं।");
        }catch(Exception e){ speak("कॉल नहीं काट सकी।"); }
    }

    // ---------- MESSAGES (notifications) ----------
    private void readNotifs(){
        List<android.service.notification.StatusBarNotification> l=MayaNotifService.top(3);
        if(l.isEmpty()){ speak("कोई नया मैसेज नहीं है। अगर Notification access चालू नहीं किया तो सेटिंग में चालू कीजिए।"); return; }
        StringBuilder sb=new StringBuilder();
        for(android.service.notification.StatusBarNotification s:l) sb.append(MayaNotifService.describe(s)).append(" ");
        speak(sb.toString()+" रिप्लाई देना हो तो बोलिए, रिप्लाई।");
    }
    private void startReply(){
        android.service.notification.StatusBarNotification s=MayaNotifService.latest();
        if(s==null){ speak("रिप्लाई देने के लिए कोई मैसेज नहीं है। Notification access चालू कीजिए।"); return; }
        pend=P_REPLY_TEXT;
        speak(MayaNotifService.who(s)+" को क्या जवाब भेजूँ?");
    }
    private void confirmReply(){ pend=P_REPLY_CONFIRM; speak("मैं यह भेज रही हूँ: "+pendB+" । भेज दूँ?"); }
    private void sendReply(String text){
        try{
            android.service.notification.StatusBarNotification s=MayaNotifService.latest();
            android.app.Notification.Action act=null;
            if(s!=null&&s.getNotification().actions!=null)
                for(android.app.Notification.Action a:s.getNotification().actions) if(a.getRemoteInputs()!=null&&a.getRemoteInputs().length>0){ act=a; break; }
            if(act==null){ speak("इस मैसेज का सीधा रिप्लाई संभव नहीं। मैं ऐप खोल देती हूँ।"); open(s!=null?s.getPackageName():"com.whatsapp",""); return; }
            android.app.RemoteInput[] ris=act.getRemoteInputs();
            Intent in=new Intent(); Bundle b=new Bundle();
            for(android.app.RemoteInput ri:ris) b.putCharSequence(ri.getResultKey(),text);
            android.app.RemoteInput.addResultsToIntent(ris,in,b);
            act.actionIntent.send(this,0,in);
            speak("रिप्लाई भेज दिया।");
        }catch(Exception e){ speak("रिप्लाई नहीं भेज सकी।"); }
    }

    // ---------- TERMUX ----------
    private void startTermux(String q){
        String cmd=removeWords(q,"termux","में","चलाओ","चला","run","कमांड","command","execute","कर","दो","माया","maya","यह","ये","को");
        if(cmd.isEmpty()){ speak(open("com.termux","Termux खोल रही हूँ।")); return; }
        pend=P_TERMUX; pendA=cmd;
        speak("मैं Termux में यह कमांड चलाऊँगी: "+cmd+" । चलाऊँ?");
    }
    private void runTermux(String cmd){
        try{
            if(checkSelfPermission("com.termux.permission.RUN_COMMAND")!=PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{"com.termux.permission.RUN_COMMAND"},REQ_PHONE);
                speak("Termux की अनुमति दीजिए, फिर दोबारा बोलिए।"); return;
            }
            Intent i=new Intent(); i.setClassName("com.termux","com.termux.app.RunCommandService"); i.setAction("com.termux.RUN_COMMAND");
            i.putExtra("com.termux.RUN_COMMAND_PATH","/data/data/com.termux/files/usr/bin/bash");
            i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS",new String[]{"-lc",cmd});
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR","/data/data/com.termux/files/home");
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND",false);
            if(android.os.Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            speak("कमांड भेज दी।");
        }catch(Exception e){
            speak("Termux कमांड नहीं चल सकी। Termux में allow external apps चालू करना होगा।");
            Toast.makeText(this,"Termux: echo \"allow-external-apps=true\" >> ~/.termux/termux.properties",Toast.LENGTH_LONG).show();
        }
    }

    // ---------- GEMINI (streaming, fast) ----------
    private interface Cb { void done(String text,String err); }
    private String buildSystemPrompt(){
        String lang=ps("reply_lang");
        String langName=lang.equals("Hinglish")?"Hinglish (Hindi written in English letters)":lang.equals("Hindi")?"Hindi in Devanagari script":lang;
        String style=ps("style");
        String st=style.equals("Detailed")?"Give a detailed answer.":style.equals("Normal")?"Give a clear answer in a few sentences.":"Keep the answer very short, one or two sentences.";
        StringBuilder b=new StringBuilder("You are Maya, a warm, sweet and friendly female voice assistant inside an Android app. Address the user as "+callName()
            +" and use that word naturally and often, written in Devanagari. Reply in "+langName+". "+st+" Use plain text only, with no markdown, lists or asterisks, because your reply is read aloud. "
            +"You are also an expert in Android, Termux commands and their errors, coding, YouTube growth (titles, keywords, thumbnails, upload settings) and general knowledge. "
            +"When a command is needed, say it plainly and briefly.");
        String about=ps("about").trim();
        if(!about.isEmpty()) b.append(" About the user: ").append(about);
        return b.toString();
    }
    private String readAll(java.io.InputStream is) throws java.io.IOException {
        if(is==null) return "";
        java.io.ByteArrayOutputStream bo=new java.io.ByteArrayOutputStream();
        byte[] buf=new byte[4096]; int n;
        while((n=is.read(buf))>0) bo.write(buf,0,n);
        return bo.toString("UTF-8");
    }
    private java.net.HttpURLConnection openGemini(String path,String key,String body) throws Exception {
        java.net.URL u=new java.net.URL("https://generativelanguage.googleapis.com/v1beta/"+path);
        java.net.HttpURLConnection c=(java.net.HttpURLConnection)u.openConnection();
        c.setRequestMethod("POST"); c.setConnectTimeout(12000); c.setReadTimeout(45000);
        c.setRequestProperty("Content-Type","application/json");
        c.setRequestProperty("x-goog-api-key",key);
        c.setDoOutput(true);
        java.io.OutputStream os=c.getOutputStream(); os.write(body.getBytes("UTF-8")); os.close();
        return c;
    }
    private String buildBody(String system,JSONArray contents,String model) throws Exception {
        JSONObject b=new JSONObject();
        b.put("systemInstruction",new JSONObject().put("parts",new JSONArray().put(new JSONObject().put("text",system))));
        b.put("contents",contents);
        JSONObject gc=new JSONObject();
        gc.put("maxOutputTokens",ps("style").equals("Detailed")?2000:700);
        if(model.contains("2.5-flash")||model.contains("flash-lite")) gc.put("thinkingConfig",new JSONObject().put("thinkingBudget",0));
        b.put("generationConfig",gc);
        return b.toString();
    }
    private java.net.HttpURLConnection openChat(String system,JSONArray contents,String key,boolean stream) throws Exception {
        ArrayList<String> cands=new ArrayList<>();
        if(!workingChat.isEmpty()) cands.add(workingChat);
        cands.add(geminiModel());
        for(String c:new String[]{"gemini-flash-latest","gemini-2.5-flash","gemini-2.5-flash-lite"}) if(!cands.contains(c)) cands.add(c);
        java.net.HttpURLConnection last=null;
        for(String m:cands){
            last=openGemini("models/"+m+(stream?":streamGenerateContent?alt=sse":":generateContent"),key,buildBody(system,contents,m));
            int code=last.getResponseCode();
            if(code!=404){ if(code>=200&&code<300) workingChat=m; return last; }
        }
        return last;
    }
    private String geminiModel(){ String m=ps("model").trim(); return m.isEmpty()?"gemini-2.5-flash":m; }
    private boolean geminiReady(){ return pb("gemini_on")&&pb("online")&&!ps("api_key").trim().isEmpty()&&online()&&System.currentTimeMillis()>=offlineUntil; }

    private void offlineFallback(){
        speak("यह जानकारी देने के लिए इंटरनेट और Gemini चाहिए। ऑफ़लाइन में मैं ऐप खोलना, कॉल, टाइमर, फ़ोटो, मैसेज पढ़ना जैसे काम कर सकती हूँ।");
    }
    private void askGemini(final String question){
        if(!pb("gemini_on")||!pb("online")){ offlineFallback(); return; }
        final String key=ps("api_key").trim();
        if(key.isEmpty()){ speak("पहले सेटिंग में Gemini API Key डालिए।"); return; }
        if(!online()||System.currentTimeMillis()<offlineUntil){ offlineFallback(); return; }
        beginSpeak(); setMode("think","THINKING");
        final int g=speakGen;
        final String model=geminiModel();
        final String sys=buildSystemPrompt();
        final ArrayList<String[]> h=new ArrayList<>(hist);
        new Thread(() -> {
            StringBuilder full=new StringBuilder();
            String err=null; int errCode=0;
            try{
                JSONArray contents=new JSONArray();
                for(String[] x:h) contents.put(new JSONObject().put("role",x[0]).put("parts",new JSONArray().put(new JSONObject().put("text",x[1]))));
                contents.put(new JSONObject().put("role","user").put("parts",new JSONArray().put(new JSONObject().put("text",question))));
                java.net.HttpURLConnection c=openChat(sys,contents,key,true);
                int code=c.getResponseCode();
                if(code<200||code>=300){
                    errCode=code;
                    String resp=readAll(c.getErrorStream());
                    err="Gemini error "+code;
                    try{ err+=": "+new JSONObject(resp).getJSONObject("error").getString("message"); }catch(Exception ignored){}
                } else {
                    java.io.BufferedReader br=new java.io.BufferedReader(new java.io.InputStreamReader(c.getInputStream(),"UTF-8"));
                    StringBuilder sb=new StringBuilder(); boolean first=true; String line;
                    while((line=br.readLine())!=null){
                        if(g!=speakGen) break;
                        if(!line.startsWith("data:")) continue;
                        String js=line.substring(5).trim();
                        if(js.isEmpty()||js.equals("[DONE]")) continue;
                        JSONArray cand=new JSONObject(js).optJSONArray("candidates");
                        if(cand==null||cand.length()==0) continue;
                        JSONObject content=cand.getJSONObject(0).optJSONObject("content");
                        if(content==null) continue;
                        JSONArray parts=content.optJSONArray("parts");
                        if(parts==null) continue;
                        for(int i=0;i<parts.length();i++){
                            JSONObject p=parts.getJSONObject(i);
                            if(p.optBoolean("thought",false)) continue;
                            String tx=p.optString("text","");
                            if(tx.isEmpty()) continue;
                            sb.append(tx); full.append(tx);
                        }
                        while(true){
                            int cut=-1;
                            for(int k=sb.length()-1;k>=0;k--){ char ch=sb.charAt(k); if(ch=='।'||ch=='.'||ch=='!'||ch=='?'||ch=='\n'){ cut=k; break; } }
                            if(cut<0||(!first&&cut+1<50)) break;
                            final String chunk=sb.substring(0,cut+1); sb.delete(0,cut+1); first=false;
                            ui.post(() -> { if(g==speakGen) speakChunk(chunk); });
                        }
                    }
                    final String rest=sb.toString();
                    if(!rest.trim().isEmpty()) ui.post(() -> { if(g==speakGen) speakChunk(rest); });
                }
            }catch(Exception e){ err="Network error: "+e.getMessage(); errCode=-1; }
            final String er=err; final int ec=errCode; final String answer=full.toString();
            ui.post(() -> {
                if(g!=speakGen) return;
                if(er!=null&&answer.isEmpty()){
                    if(ec==-1){ offlineUntil=System.currentTimeMillis()+45000; speakChunk("इंटरनेट में दिक्कत है, मैं ऑफ़लाइन मोड में काम कर रही हूँ।"); }
                    else if(ec==400||ec==401||ec==403){ speakChunk("Gemini API Key या मॉडल का नाम सही नहीं लग रहा। सेटिंग में जाँचिए।"); Toast.makeText(this,er,Toast.LENGTH_LONG).show(); }
                    else if(ec==429){ speakChunk("Gemini की सीमा पूरी हो गई है। थोड़ी देर बाद कोशिश कीजिए।"); }
                    else { speakChunk("Gemini से जवाब नहीं मिला।"); Toast.makeText(this,er,Toast.LENGTH_LONG).show(); }
                } else if(pb("history")){
                    hist.add(new String[]{"user",question}); hist.add(new String[]{"model",answer});
                    while(hist.size()>8) hist.remove(0);
                    transcript.setText(answer);
                }
                endSpeak();
            });
        }).start();
    }
    private void geminiOnce(final String prompt,final String system,final Cb cb){
        final String key=ps("api_key").trim(); final String model=geminiModel();
        new Thread(() -> {
            String out=null,err=null;
            try{
                JSONArray contents=new JSONArray().put(new JSONObject().put("role","user").put("parts",new JSONArray().put(new JSONObject().put("text",prompt))));
                java.net.HttpURLConnection c=openChat(system,contents,key,false);
                int code=c.getResponseCode();
                String resp=readAll(code>=200&&code<300?c.getInputStream():c.getErrorStream());
                if(code>=200&&code<300) out=new JSONObject(resp).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
                else err="Gemini error "+code;
            }catch(Exception e){ err="Network error: "+e.getMessage(); }
            final String o=out,e2=err;
            ui.post(() -> cb.done(o,e2));
        }).start();
    }

    // ---------- MENU / MISC ----------
    private void showMenu(){
        String[] items={"Settings ("+countSettings()+")","Features (37)","Test Gemini","Self Test","Quiet mode (चुप)","Coding Assistant","Important Call Numbers"};
        new AlertDialog.Builder(this).setTitle("MAYA MENU").setItems(items,(d,w)->{
            if(w==0)showSettingsPage(); else if(w==1)showSettings(); else if(w==2)askGemini("एक छोटा सा नमस्ते बोलो और बताओ कि तुम तैयार हो।");
            else if(w==3)selfTest(); else if(w==4)toggleQuiet(); else if(w==5)codingAssistant(); else showImportantNumbers();
        }).show();
    }
    private void showSettings(){
        ScrollView sc=new ScrollView(this); LinearLayout list=column();
        list.setPadding(dp(20),dp(16),dp(20),dp(20)); sc.addView(list);
        TextView title=label("MAYA FEATURES",24,Color.WHITE); title.setTypeface(null,1); list.addView(title);
        TextView bg=label("37 फीचर नियंत्रण · मुख्य स्क्रीन से अलग",12,0xff91ad9d); list.addView(bg);
        sc.setBackgroundColor(0xff09110d);
        for(int n=0;n<featureNames.length;n++){
            final int id=n+1; Switch sw=new Switch(this);
            sw.setText(String.format(Locale.ROOT,"%02d  %s",id,featureNames[n]));
            sw.setTextColor(0xffd8e7de); sw.setTextSize(13); sw.setPadding(0,dp(8),0,dp(8));
            sw.setChecked(prefs.getBoolean("feature_"+id,true));
            sw.setOnCheckedChangeListener((b,c)->prefs.edit().putBoolean("feature_"+id,c).apply());
            list.addView(sw);
            View line=new View(this); line.setBackgroundColor(0xff20352a); list.addView(line,lp(-1,1));
        }
        new AlertDialog.Builder(this).setTitle("FEATURES").setView(sc)
            .setPositiveButton("DONE",(d,w)->showHome()).show();
    }
    private void selfTest(){
        String mic=checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED?"Granted":"Not granted";
        String speech=SpeechRecognizer.isRecognitionAvailable(this)?"Available":"Unavailable";
        new AlertDialog.Builder(this).setTitle("SELF TEST")
            .setMessage("Microphone permission: "+mic+"\nSpeech service: "+speech+
                "\nQuiet mode: "+(quiet?"On":"Off")+"\nGemini On/Off: "+(pb("gemini_on")?"On":"Off")+"\nGemini API key: "+(ps("api_key").trim().isEmpty()?"Not set":"Set")+"\nModel: "+ps("model")+"\nInternet use: "+(pb("online")?"On":"Off"))
            .setPositiveButton("OK",null).show();
    }
    private void codingAssistant(){
        EditText input=new EditText(this); input.setHint("बताइए कौन-सा कोड चाहिए");
        new AlertDialog.Builder(this).setTitle("CODING ASSISTANT").setMessage("यह UI अभी Gemini/API से जुड़ा नहीं है; यह code generation का दावा नहीं करेगा।")
            .setView(input).setPositiveButton("CLOSE",null).show();
    }
    private void showImportantNumbers(){
        Toast.makeText(this,"Important Call Numbers module इस visual prototype में अभी पूरा नहीं जोड़ा गया।",Toast.LENGTH_LONG).show();
    }
    @Override protected void onDestroy(){
        micOn=false; ui.removeCallbacksAndMessages(null);
        try{ unregisterReceiver(phoneRx); }catch(Exception ignored){}
        try{ if(netCb!=null) ((android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE)).unregisterNetworkCallback(netCb); }catch(Exception ignored){}
        muteBeep(false);
        try{ stopService(new Intent(this,MayaFgService.class)); }catch(Exception ignored){}
        stopOutput();
        ttsExec.shutdownNow();
        if(recognizer!=null) recognizer.destroy();
        if(tts!=null){ tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    class OrbView extends View {
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint tp=new Paint(Paint.ANTI_ALIAS_FLAG);
        final float[] hsv=new float[3];
        String mode="idle"; float t=0; long last=0;
        final android.os.Handler h=new android.os.Handler(android.os.Looper.getMainLooper());
        final Runnable anim=new Runnable(){ public void run(){
            long now=System.nanoTime(); if(last==0) last=now;
            float dt=Math.min(.1f,(now-last)/1e9f); last=now;
            float sp=mode.equals("quiet")?.45f:mode.equals("listen")?1.5f:mode.equals("speak")?1.8f:mode.equals("think")?2.3f:1f;
            sp*=pick("orb_speed",.6f,1f,1.6f); t+=dt*sp; invalidate(); h.postDelayed(this,16);
        }};
        OrbView(android.content.Context c){
            super(c);
            tp.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD));
            tp.setTextAlign(Paint.Align.CENTER);
            h.post(anim);
        }
        @Override protected void onDetachedFromWindow(){ h.removeCallbacks(anim); super.onDetachedFromWindow(); }
        int al(int col,int a){ return Color.argb(a,Color.red(col),Color.green(col),Color.blue(col)); }
        int hue(float deg,float sat){ hsv[0]=((deg%360f)+360f)%360f; hsv[1]=sat; hsv[2]=1f; return Color.HSVToColor(hsv); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float w=getWidth(),hh=getHeight(),cx=w/2f,cy=hh/2f;
            float R=Math.min(w,hh)/2f-dp(6);
            int glow=mode.equals("quiet")?0xff5f7f96:mode.equals("listen")?0xff35d6ff:mode.equals("speak")?0xffa5ff58:mode.equals("think")?0xffb06bff:0xff3df5a0;
            String th=ps("theme");
            if(th.equals("Green")) glow=0xff3df5a0; else if(th.equals("Blue")) glow=0xff35a8ff; else if(th.equals("Purple")) glow=0xffb06bff; else if(th.equals("Rainbow")) glow=hue(t*40f,.7f);
            float pulse=(float)Math.sin(t*2.2f);

            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(cx,cy,R,new int[]{al(glow,110),al(glow,40),0x00000000},new float[]{.35f,.75f,1f},Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,R,p); p.setShader(null);

            p.setShader(new RadialGradient(cx-R*.1f,cy-R*.15f,R*.72f,new int[]{al(glow,60+(int)(25*pulse)),0xff0a1612,0xff050a08},new float[]{0f,.65f,1f},Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,R*.70f,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.2f)); p.setColor(al(glow,120));
            c.drawCircle(cx,cy,R*.70f,p);
            p.setStyle(Paint.Style.FILL);

            int n=72; float rr=R*.86f;
            for(int i=0;i<n;i++){
                float ang=(float)(2*Math.PI*i/n+t*.35f);
                float s=.5f+.5f*(float)Math.sin(ang*3-t*3f);
                p.setColor(hue(i*360f/n+t*60f,.75f));
                c.drawCircle(cx+rr*(float)Math.cos(ang),cy+rr*(float)Math.sin(ang),dp(1.5f)+dp(2.3f)*s,p);
            }
            int n2=48; float r2=R*.77f;
            for(int i=0;i<n2;i++){
                float ang=(float)(-2*Math.PI*i/n2-t*.5f);
                float s=.5f+.5f*(float)Math.sin(ang*2+t*2f);
                p.setColor(al(hue(i*360f/n2-t*40f+180f,.6f),200));
                c.drawCircle(cx+r2*(float)Math.cos(ang),cy+r2*(float)Math.sin(ang),dp(1f)+dp(1.1f)*s,p);
            }
            for(int k=0;k<2;k++){
                float head=t*1.1f+k*(float)Math.PI;
                for(int j=0;j<18;j++){
                    float ang=head-j*.055f;
                    float f=1f-j/18f;
                    p.setColor(al(Color.WHITE,(int)(255*f*f)));
                    c.drawCircle(cx+rr*(float)Math.cos(ang),cy+rr*(float)Math.sin(ang),dp(.8f)+dp(3.4f)*f,p);
                }
            }

            if(pb("orb_text")){
            String txt="MAYA";
            float target=R*1.12f;
            tp.setLetterSpacing(.08f); tp.setTextSize(R*.4f);
            float wt=tp.measureText(txt);
            tp.setTextSize(R*.4f*target/wt);
            LinearGradient lg=new LinearGradient(cx-target/2f,0,cx+target/2f,0,
                new int[]{0xffff4fd8,0xff4fc3ff,0xff5dffa0,0xffffd54f,0xffff4fd8},null,Shader.TileMode.REPEAT);
            Matrix m=new Matrix(); m.setTranslate((t*70f)%target,0); lg.setLocalMatrix(m);
            tp.setShader(lg);
            float ty=cy-(tp.descent()+tp.ascent())/2f;
            c.drawText(txt,cx,ty,tp);
            }
        }
    }
    class EdgeGlow extends View {
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        float ang=0; long last=0;
        final android.os.Handler h=new android.os.Handler(android.os.Looper.getMainLooper());
        final int[] cometCols={0x00ffffff,0x00ffffff,0x661cf4a0,0xff2aa8ff,0xffff4fd8,0xffffffff,0x00ffffff};
        final float[] cometPos={0f,.62f,.72f,.84f,.93f,.985f,1f};
        final int[] cols={0xff1cf4a0,0xff2aa8ff,0xff8a4cff,0xffff4fd8,0xffffb02e,0xff1cf4a0};
        final Runnable anim=new Runnable(){ public void run(){
            long now=System.nanoTime(); if(last==0) last=now;
            float dt=Math.min(.1f,(now-last)/1e9f); last=now;
            ang+=dt*70f*pick("edge_speed",.5f,1f,1.9f);
            invalidate(); h.postDelayed(this,33);
        }};
        EdgeGlow(android.content.Context c){ super(c); setWillNotDraw(false); h.post(anim); }
        @Override protected void onDetachedFromWindow(){ h.removeCallbacks(anim); super.onDetachedFromWindow(); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float w=getWidth(),hh=getHeight();
            if(w<=0||hh<=0||!pb("edge_on")) return;
            SweepGradient sg=new SweepGradient(w/2f,hh/2f,cols,null);
            Matrix m=new Matrix(); m.setRotate(ang%360f,w/2f,hh/2f); sg.setLocalMatrix(m);
            p.setShader(sg); p.setStyle(Paint.Style.STROKE);
            float in=dp(4);
            float tf=pick("edge_thick",.6f,1f,1.6f);
            p.setStrokeWidth(dp(10)*tf); p.setAlpha(45);
            c.drawRoundRect(in,in,w-in,hh-in,dp(28),dp(28),p);
            p.setStrokeWidth(dp(5)*tf); p.setAlpha(100);
            c.drawRoundRect(in,in,w-in,hh-in,dp(28),dp(28),p);
            p.setStrokeWidth(dp(2.5f)*tf); p.setAlpha(255);
            c.drawRoundRect(in,in,w-in,hh-in,dp(28),dp(28),p);
            SweepGradient cg=new SweepGradient(w/2f,hh/2f,cometCols,cometPos);
            Matrix m2=new Matrix(); m2.setRotate((ang*1.35f)%360f,w/2f,hh/2f); cg.setLocalMatrix(m2);
            p.setShader(cg); p.setStrokeWidth(dp(4.5f)*tf); p.setAlpha(255);
            c.drawRoundRect(in,in,w-in,hh-in,dp(28),dp(28),p);
        }
    }
    class IconButton extends View {
        final int kind; boolean active=false;
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint tp=new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path path=new Path();
        IconButton(android.content.Context c,int kind){ super(c); this.kind=kind; }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float w=getWidth(),hh=getHeight(),cx=w/2f,cy=hh/2f;
            if(kind==7){
                float ph=hh*.72f, in=dp(2);
                RectF pill=new RectF(in,cy-ph/2f,w-in,cy+ph/2f);
                p.setStyle(Paint.Style.FILL);
                if(active) p.setShader(new LinearGradient(0,0,w,0,0xff1cf4a0,0xff2aa8ff,Shader.TileMode.CLAMP)); else p.setColor(0xff111a16);
                c.drawRoundRect(pill,ph/2f,ph/2f,p); p.setShader(null);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f)); p.setColor(active?0xffb8ffe0:0xff3a4a42);
                c.drawRoundRect(pill,ph/2f,ph/2f,p);
                tp.setStyle(Paint.Style.FILL); tp.setTextAlign(Paint.Align.CENTER); tp.setTypeface(Typeface.DEFAULT_BOLD);
                tp.setTextSize(ph*.52f); tp.setColor(active?0xff04120b:0xff8aa296);
                c.drawText("AI",cx,cy-(tp.descent()+tp.ascent())/2f,tp);
                if(!active){
                    p.setColor(0xffff5c5c); p.setStrokeWidth(dp(2.2f)); p.setStrokeCap(Paint.Cap.ROUND);
                    c.drawLine(cx-ph*.5f,cy+ph*.32f,cx+ph*.5f,cy-ph*.32f,p);
                }
                return;
            }
            float r=Math.min(w,hh)/2f-dp(5);
            p.setShader(null); p.setStyle(Paint.Style.FILL);
            p.setColor(active?0xff12402c:0xff0f1a15); c.drawCircle(cx,cy,r,p);
            if(active){
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(6)); p.setColor(0x4063f5a5);
                c.drawCircle(cx,cy,r+dp(2),p);
            }
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f));
            p.setColor(active?0xff63f5a5:0xff2f6b4a); c.drawCircle(cx,cy,r,p);
            p.setColor(active?0xffeafff2:0xffb8f4d0); p.setStrokeWidth(dp(2.2f));
            p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
            float u=r*.5f;
            if(kind==0){
                c.drawRoundRect(new RectF(cx-u*.34f,cy-u*.95f,cx+u*.34f,cy+u*.15f),u*.34f,u*.34f,p);
                c.drawArc(new RectF(cx-u*.62f,cy-u*.45f,cx+u*.62f,cy+u*.55f),0,180,false,p);
                c.drawLine(cx,cy+u*.55f,cx,cy+u*.9f,p);
                c.drawLine(cx-u*.32f,cy+u*.9f,cx+u*.32f,cy+u*.9f,p);
            } else if(kind==1){
                c.drawRoundRect(new RectF(cx-u*.95f,cy-u*.5f,cx+u*.95f,cy+u*.7f),u*.22f,u*.22f,p);
                path.reset(); path.moveTo(cx-u*.4f,cy-u*.5f); path.lineTo(cx-u*.22f,cy-u*.82f);
                path.lineTo(cx+u*.22f,cy-u*.82f); path.lineTo(cx+u*.4f,cy-u*.5f);
                c.drawPath(path,p);
                c.drawCircle(cx,cy+u*.1f,u*.36f,p);
            } else if(kind==2){
                c.drawCircle(cx,cy,u*.5f,p);
                c.drawCircle(cx,cy,u*.18f,p);
                p.setStrokeWidth(dp(3.4f));
                for(int i=0;i<8;i++){
                    c.save(); c.rotate(i*45f,cx,cy);
                    c.drawLine(cx,cy-u*.62f,cx,cy-u*.88f,p);
                    c.restore();
                }
            } else if(kind==4){
                c.drawRoundRect(new RectF(cx-u*.9f,cy-u*.7f,cx+u*.9f,cy+u*.7f),u*.2f,u*.2f,p);
                c.drawCircle(cx+u*.4f,cy-u*.2f,u*.16f,p);
                path.reset(); path.moveTo(cx-u*.9f,cy+u*.5f); path.lineTo(cx-u*.35f,cy-u*.05f); path.lineTo(cx+u*.05f,cy+u*.35f);
                path.lineTo(cx+u*.35f,cy+u*.1f); path.lineTo(cx+u*.9f,cy+u*.55f); c.drawPath(path,p);
            } else if(kind==5){
                c.drawCircle(cx,cy,u*.8f,p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx-u*.28f,cy-u*.2f,u*.09f,p); c.drawCircle(cx+u*.28f,cy-u*.2f,u*.09f,p);
                p.setStyle(Paint.Style.STROKE);
                c.drawArc(new RectF(cx-u*.4f,cy-u*.15f,cx+u*.4f,cy+u*.45f),20,140,false,p);
            } else if(kind==6){
                Path a=new Path(); a.addCircle(cx,cy,u*.8f,Path.Direction.CW);
                Path bb=new Path(); bb.addCircle(cx+u*.45f,cy-u*.3f,u*.7f,Path.Direction.CW);
                a.op(bb,Path.Op.DIFFERENCE);
                p.setStyle(Paint.Style.FILL); c.drawPath(a,p); p.setStyle(Paint.Style.STROKE);
            } else {
                c.drawCircle(cx,cy-u*.35f,u*.32f,p);
                c.drawArc(new RectF(cx-u*.72f,cy+u*.05f,cx+u*.72f,cy+u*1.3f),180,180,false,p);
            }
        }
    }
}
