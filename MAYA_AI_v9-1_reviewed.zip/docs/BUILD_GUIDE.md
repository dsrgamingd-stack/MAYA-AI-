# Build guide

## Android Studio (recommended)
1. Project folder extract करें.
2. Android Studio में `MAYA_AI` folder खोलें.
3. JDK 17 और Android SDK Platform 35 install/select करें.
4. Gradle sync करें; Gradle 8.9 उपयोग करें.
5. Build > Build APK(s).
6. APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
Repository में पूरा project upload/push करें. Actions tab में `Build MAYA AI Debug APK` workflow चलाएँ. Successful run में `MAYA-AI-debug-apk` artifact डाउनलोड करें.

## Termux
1. पहले Android SDK सेटअप करें (android_env_bash.sh, option 1)।
2. ज़िप को Termux के होम में खोलें, फिर प्रोजेक्ट फ़ोल्डर में जाएँ।
3. `bash termux_build.sh` चलाएँ। यह local.properties और aapt2 सेटिंग अपने आप लगाता है।
4. APK `Download/MayaAI-debug.apk` में मिलेगा।

## Android 14/15 background startup note

Android की background-start restrictions के कारण फोन boot होते ही माइक्रोफ़ोन foreground service अपने आप शुरू नहीं किया जाता। Boot notification दिखाई जाती है; उसे टैप करने पर MAYA खुलेगी। माइक्रोफ़ोन शुरू करने के लिए ऐप में अनुमति और user action आवश्यक है।
